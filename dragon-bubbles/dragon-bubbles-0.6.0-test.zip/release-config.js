window.CandyRelease=Object.freeze({version:'0.6.0',playtest:true});
