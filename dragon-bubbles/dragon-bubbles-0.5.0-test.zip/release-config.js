window.CandyRelease=Object.freeze({version:'0.5.0',playtest:true});
