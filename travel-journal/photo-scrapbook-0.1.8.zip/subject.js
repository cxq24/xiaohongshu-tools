(function () {
  'use strict';
  // An NHWC CPU runner for the bundled U²-Net-P foreground output.
  // Only its six operator types are supported.
  const model=self.JournalSubjectWeights;
  let orderedWeights,parameters;
  const now=function () {return performance.now();};

  function decode(encoded) {
    const binary=atob(encoded), bytes=new Uint8Array(binary.length);
    for(let i=0;i<bytes.length;i++) bytes[i]=binary.charCodeAt(i);
    return bytes;
  }
  function initialize() {
    if(orderedWeights) return;
    const halves=[decode(model.quantized),decode(model.tail)];
    const weight=new Int16Array((halves[0].length+halves[1].length)/2);
    let index=0;
    halves.forEach(function (bytes) {
      const view=new DataView(bytes.buffer);
      for(let i=0;i<bytes.length;i+=2) weight[index++]=view.getInt16(i,true);
    });
    const data=decode(model.parameters);
    const view=new DataView(data.buffer);
    parameters=new Float32Array(data.length/4);
    for(let i=0;i<parameters.length;i++) parameters[i]=view.getFloat32(i*4,true);
    orderedWeights=weight;
  }
  function tensor(size,channels) {
    return {size:size,channels:channels,data:new Float32Array(size*size*channels)};
  }
  function inputs(op) {
    return op[0]==='concat' || op[0]==='add' ? op.slice(1) : [op[1]];
  }

  async function convolve(input,op,relax) {
    const out=op[2], kernel=op[3], dilation=op[4];
    const offset=op[5], startingParam=op[6], relu=op[7];
    const size=input.size, inc=input.channels, src=input.data;
    const result=tensor(size,out), output=result.data;
    const filterSize=kernel*kernel*inc*4;
    const border=Math.floor(kernel/2)*dilation;
    const blocks=Math.ceil(out/4), bpad=blocks*4;
    const weights=orderedWeights;
    const max=size-1;
    const kStride=kernel*inc*4;
    const xStride=inc*4;
    for(let y=0;y<size;y++) {
      if((y&3)===0) {
        const pause=relax();
        if(pause) await pause;
      }
      const baseY=y-border;
      const firstY=Math.max(0,Math.ceil(-baseY/dilation));
      const endY=Math.min(kernel,1+Math.floor((max-baseY)/dilation));
      for(let x=0;x<size;x++) {
        const baseX=x-border;
        const firstX=Math.max(0,Math.ceil(-baseX/dilation));
        const endX=Math.min(kernel,1+Math.floor((max-baseX)/dilation));
        let position=(y*size+x)*out;
        for(let group=0;group<blocks;group++) {
          const base=offset+group*filterSize;
          let a=0,b=0,c=0,d=0;
          for(let ky=firstY;ky<endY;ky++) {
            const row=(baseY+ky*dilation)*size;
            let filter=base+ky*kStride+firstX*xStride;
            for(let kx=firstX;kx<endX;kx++) {
              let index=(row+baseX+kx*dilation)*inc;
              const limit=index+inc;
              while(index<limit) {
                const number=src[index++];
                a+=number*weights[filter];b+=number*weights[filter+1];
                c+=number*weights[filter+2];d+=number*weights[filter+3];
                filter+=4;
              }
            }
          }
          const p=startingParam+group*4;
          a=a*parameters[p+bpad]+parameters[p];
          output[position++]=relu?Math.max(0,a):a;
          if(out>1) {
            b=b*parameters[p+bpad+1]+parameters[p+1];
            c=c*parameters[p+bpad+2]+parameters[p+2];
            d=d*parameters[p+bpad+3]+parameters[p+3];
            output[position++]=relu?Math.max(0,b):b;
            output[position++]=relu?Math.max(0,c):c;
            output[position++]=relu?Math.max(0,d):d;
          }
        }
      }
    }
    return result;
  }
  function maxPool(input) {
    const size=input.size, channels=input.channels, data=input.data;
    const res=tensor(Math.ceil(size/2),channels);
    let out=0;
    for(let y=0;y<size;y+=2) {
      for(let x=0;x<size;x+=2) {
        const p=(y*size+x)*channels;
        const dx=x+1<size?channels:0,dy=y+1<size?size*channels:0;
        for(let c=0;c<channels;c++) {
          const offset=p+c;
          res.data[out++]=Math.max(data[offset],data[offset+dx],data[offset+dy],data[offset+dx+dy]);
        }
      }
    }
    return res;
  }
  function resize(input,size) {
    const old=input.size,channels=input.channels,data=input.data;
    const res=tensor(size,channels);
    const scale=old/size;
    const toBase=new Uint16Array(size),toEnd=new Uint16Array(size),portion=new Float32Array(size);
    for(let x=0;x<size;x++) {
      const from=Math.min(old-1,Math.max(0,size===1?0:(x+.5)*scale-.5));
      toBase[x]=Math.floor(from);toEnd[x]=Math.min(old-1,toBase[x]+1);portion[x]=from-toBase[x];
    }
    let p=0;
    for(let y=0;y<size;y++) {
      const row=toBase[y]*old,last=toEnd[y]*old,dy=portion[y];
      for(let x=0;x<size;x++) {
        const l=toBase[x],r=toEnd[x],dx=portion[x];
        const a=(row+l)*channels,b=(row+r)*channels,c=(last+l)*channels,d=(last+r)*channels;
        for(let n=0;n<channels;n++) {
          const top=data[a+n]+(data[b+n]-data[a+n])*dx;
          const bottom=data[c+n]+(data[d+n]-data[c+n])*dx;
          res.data[p++]=top+(bottom-top)*dy;
        }
      }
    }
    return res;
  }
  function concatenate(args) {
    const res=tensor(args[0].size,args.reduce(function (count,t) {return count+t.channels;},0));
    let out=0;
    for(let p=0;p<res.size*res.size;p++) {
      for(let i=0;i<args.length;i++) {
        const t=args[i],start=p*t.channels;
        for(let c=0;c<t.channels;c++) res.data[out++]=t.data[start+c];
      }
    }
    return res;
  }
  function add(left,right) {
    const res=tensor(left.size,left.channels);
    for(let i=0;i<res.data.length;i++) res.data[i]=left.data[i]+right.data[i];
    return res;
  }
  function sigmoid(input) {
    const res=tensor(input.size,input.channels);
    for(let i=0;i<res.data.length;i++) res.data[i]=1/(1+Math.exp(-input.data[i]));
    return res;
  }

  async function predict(pixels,size,alive) {
    if(!model) throw new Error('主体模型不可用');
    initialize();
    const input=tensor(size,3), mean=[.485,.456,.406], deviation=[.229,.224,.225];
    let maximum=1;
    for(let p=0;p<pixels.length;p+=4) maximum=Math.max(maximum,pixels[p],pixels[p+1],pixels[p+2]);
    for(let p=0,i=0;p<pixels.length;p+=4) {
      for(let c=0;c<3;c++) input.data[i++]=(pixels[p+c]/maximum-mean[c])/deviation[c];
    }
    let until=now()+22;
    function relax() {
      if(now()<until) return null;
      return new Promise(function (resolve) {setTimeout(resolve,0);}).then(function () {
        if(alive && !alive()) throw new Error('已取消');
        until=now()+22;
      });
    }
    const graph=model.graph;
    const live=new Uint16Array(graph.length+1);
    graph.forEach(function (op) {inputs(op).forEach(function (key) {live[key]++;});});
    const tensors=[input];
    for(let i=0;i<graph.length;i++) {
      const op=graph[i], source=tensors[op[1]];
      let value;
      switch(op[0]) {
        case 'conv': value=await convolve(source,op,relax);break;
        case 'pool': value=maxPool(source);break;
        case 'resize': value=resize(source,size*op[2]/320);break;
        case 'concat': value=concatenate(op.slice(1).map(function (key) {return tensors[key];}));break;
        case 'add': value=add(source,tensors[op[2]]);break;
        case 'sigmoid': value=sigmoid(source);break;
        default: throw new Error('主体模型结构无法读取');
      }
      tensors.push(value);
      inputs(op).forEach(function (key) {if(--live[key]===0) tensors[key]=null;});
      const pause=relax();
      if(pause) await pause;
    }
    return tensors[tensors.length-1].data;
  }

  self.JournalSubject={predict:predict};
})();
