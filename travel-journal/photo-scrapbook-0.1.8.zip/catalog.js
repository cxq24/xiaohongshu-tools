(function () {
  'use strict';
  const layouts = [
    {id:'single', name:'单张封面', slots:[[0.50,0.51,0.76,0.50,-3,'tear']]},
    {id:'duo', name:'双图对照', slots:[[0.33,0.46,0.44,0.38,-7,'instant'],[0.68,0.60,0.43,0.36,7,'instant']]},
    {id:'triple', name:'三图拼贴', slots:[[0.40,0.43,0.67,0.34,-7,'tear'],[0.72,0.64,0.36,0.28,8,'instant'],[0.29,0.68,0.30,0.22,-10,'stamp']]},
    {id:'wall', name:'多图照片墙', slots:[[0.27,0.36,0.34,0.22,-4,'instant'],[0.72,0.36,0.34,0.22,5,'stamp'],[0.27,0.58,0.34,0.22,4,'stamp'],[0.72,0.58,0.34,0.22,-5,'instant'],[0.27,0.78,0.32,0.17,-3,'tear'],[0.72,0.78,0.32,0.17,4,'tear']]},
    {id:'timeline', name:'时间线', slots:[[0.39,0.34,0.53,0.21,-3,'tear'],[0.63,0.56,0.51,0.22,3,'instant'],[0.37,0.77,0.50,0.19,-3,'stamp']]},
    {id:'tickets', name:'票据收藏页', slots:[[0.37,0.44,0.54,0.25,-8,'stamp'],[0.64,0.66,0.56,0.23,7,'ticket']]},
    {id:'free', name:'自由拼贴', slots:[]}
  ];
  const papers = [
    {id:'kraft',name:'牛皮纸',base:'#efe0bc',ink:'#39362a',line:'#aa9467',pattern:'kraft'},
    {id:'fiber',name:'米白纤维纸',base:'#f5efdf',ink:'#3b3a30',line:'#b6a58e',pattern:'fiber'},
    {id:'plain',name:'暖白素纸',base:'#fbf5e8',ink:'#393a31',line:'#b4a082',pattern:'plain'},
    {id:'grid',name:'方格本',base:'#f5efdd',ink:'#3f4c45',line:'#aab1a1',pattern:'grid'},
    {id:'dots',name:'点阵本',base:'#ecead8',ink:'#434d3d',line:'#8f9a87',pattern:'dots'},
    {id:'ruled',name:'横线本',base:'#fcf3e3',ink:'#3d443c',line:'#beaa99',pattern:'ruled'},
    {id:'airmail',name:'航空信纸',base:'#f0eee2',ink:'#32465b',line:'#8297ac',pattern:'airmail'},
    {id:'news',name:'旧报纸',base:'#e8debd',ink:'#41382b',line:'#aa926a',pattern:'news'},
    {id:'map',name:'旧地图',base:'#eee6c7',ink:'#3f513c',line:'#8c9980',pattern:'map'},
    {id:'film',name:'胶片杂志',base:'#eee4d2',ink:'#372f2b',line:'#887565',pattern:'film'},
    {id:'torn',name:'彩色撕纸',base:'#f4e4d8',ink:'#4e3b36',line:'#b98076',pattern:'torn'},
    {id:'watercolor',name:'浅色水彩纸',base:'#f7eee4',ink:'#534349',line:'#b8898e',pattern:'watercolor'}
  ];
  const paperPreviews = {
    kraft:'radial-gradient(ellipse at 35% 25%,#f5e4bc,#d5bd8d)',
    fiber:'repeating-linear-gradient(23deg,transparent 0,transparent 4px,rgba(202,183,150,0.3333) 5px,transparent 6px)',
    plain:'linear-gradient(135deg,#fff8e9,#f0e4cd)',
    grid:'repeating-linear-gradient(0deg,transparent 0,transparent 6px,#b0b6a2 7px),repeating-linear-gradient(90deg,transparent 0,transparent 6px,#b0b6a2 7px)',
    dots:'radial-gradient(#a0ad96 1px,transparent 1px)',
    ruled:'repeating-linear-gradient(0deg,transparent 0,transparent 5px,#b7a08c 6px,transparent 7px)',
    airmail:'linear-gradient(0deg,#a8544d 0,#a8544d 10%,transparent 10%,transparent 88%,#6d889e 88%)',
    news:'repeating-linear-gradient(0deg,transparent 0,transparent 2px,rgba(160,140,101,0.4000) 3px,transparent 4px)',
    map:'repeating-linear-gradient(-18deg,transparent 0,transparent 4px,rgba(142,154,119,0.5333) 5px,rgba(142,154,119,0.5333) 6px,transparent 7px)',
    film:'linear-gradient(90deg,#514942 0,#514942 14%,transparent 14%,transparent 86%,#514942 86%)',
    torn:'linear-gradient(154deg,#d8ba9b 0,#e9c7ad 30%,#f4e4d8 31%,#f4e4d8 62%,#cbd0b0 63%)',
    watercolor:'radial-gradient(ellipse at 20% 0%,#c8ccb6,transparent 65%),radial-gradient(ellipse at 90% 75%,#dcacac,transparent 65%)'
  };
  const decor = [
    {id:'ticket',label:'日期票根',symbol:'◫',color:'#9d4b39'},
    {id:'tape',label:'纸胶带',symbol:'▰',color:'#a66d4c'},
    {id:'stamp',label:'纪念邮戳',symbol:'◎',color:'#a4513a'},
    {id:'note',label:'手写便签',symbol:'Aa',color:'#677452'},
    {id:'route',label:'手绘路线',symbol:'⋯',color:'#7b8265'},
    {id:'spark',label:'小星星',symbol:'✦',color:'#b87849'}
  ];
  const icons = {
    brand:'<path d="M5 5.5h11a2 2 0 0 1 2 2V20H7.5A2.5 2.5 0 0 1 5 17.5z"/><path d="M5 17a2 2 0 0 1 2-2h11M8 5.5v9.5M11 12l2-3.5 2 3.5m4-8 1 .8-.9.9-.8-.9z"/>',
    edit:'<path d="m14 5 5 5M5 19l4.2-.8L20 7.4a1.6 1.6 0 0 0 0-2.2l-1.2-1.2a1.6 1.6 0 0 0-2.2 0L5.8 14.8 5 19Z"/>',
    book:'<path d="M5 5a2 2 0 0 1 2-2h12v16H7a2 2 0 0 0 0 4h12M5 5v16M9 7h6m-6 4h5"/>',
    'book-add':'<path d="M5 5a2 2 0 0 1 2-2h12v16H7a2 2 0 0 0 0 4h12M5 5v16m4-10h6m-3-3v6"/>',
    image:'<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="m4 17.5 5-5 3 3 2.5-2.5 5 4.5"/><circle cx="15.5" cy="9" r="1.2"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    undo:'<path d="M9 7 4 12l5 5m-5-5h10a5 5 0 0 1 5 5"/>',
    redo:'<path d="m15 7 5 5-5 5m5-5H10a5 5 0 0 0-5 5"/>',
    file:'<path d="M6 3h9l4 4v14H6zM14 3v5h5M12.5 11v6m-3-3h6"/>',
    move:'<path d="M12 3v18M3 12h18M9 6l3-3 3 3m-6 12 3 3 3-3M6 9l-3 3 3 3m12-6 3 3-3 3"/>',
    rotate:'<path d="M19 10a7 7 0 1 0-1.2 6.8M19 4v6h-6"/>',
    resize:'<path d="M9 15 15 9M15 5h4v4M9 19H5v-4M19 5l-5 5m-4 4-5 5"/>',
    scissors:'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="m8.4 7.8 12 10.2M8.4 16.2 20.4 6"/>',
    crop:'<path d="M6 3v14a1 1 0 0 0 1 1h14M3 6h14a1 1 0 0 1 1 1v14"/>',
    layers:'<path d="m12 4-8 5 8 5 8-5-8-5Zm-8 9 8 5 8-5M4 17l8 5 8-5"/>',
    trash:'<path d="M4 6h16M9 6V4h6v2m3 0-1 14H7L6 6m4 4v6m4-6v6"/>',
    download:'<path d="M12 3v12m-4-4 4 4 4-4M5 15v5h14v-5"/>',
    send:'<path d="m3 11 18-8-6 18-3.2-7.8L3 11Zm8.8 2.2L21 3"/>',
    left:'<path d="m15 5-7 7 7 7"/>',
    right:'<path d="m9 5 7 7-7 7"/>',
    up:'<path d="m5 15 7-7 7 7"/>',
    down:'<path d="m5 9 7 7 7-7"/>',
    sort:'<path d="M5 6h11m-11 6h11m-11 6h8m5-1 2 2 2-2m-2-8v10"/>',
    grip:'<path d="M6 8h12M6 12h12M6 16h12"/>',
    lock:'<rect x="6" y="10" width="12" height="10" rx="2"/><path d="M9 10V7a3 3 0 0 1 6 0v3m-3 4v2"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>'
  };
  window.JournalCatalog = {layouts:layouts,papers:papers,paperPreviews:paperPreviews,decor:decor,icons:icons};
})();
