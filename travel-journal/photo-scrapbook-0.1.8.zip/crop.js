(function () {
  'use strict';
  const art=window.JournalArt;
  const labels={instant:'拍立得',tear:'撕纸边',stamp:'邮票边',round:'圆形',ticket:'票据卡'};
  function coordinates(event,canvas) {
    const rect=canvas.getBoundingClientRect();
    return [
      (event.clientX-rect.left-canvas.clientLeft)*canvas.width/canvas.clientWidth,
      (event.clientY-rect.top-canvas.clientTop)*canvas.height/canvas.clientHeight
    ];
  }
  function bindDrag(canvas,begin,move,end) {
    let active=null;
    canvas.addEventListener('pointerdown',function (event) {
      if (active!==null || event.button!==0) return;
      event.preventDefault();
      active=event.pointerId;
      canvas.setPointerCapture(active);
      begin(coordinates(event,canvas));
    });
    canvas.addEventListener('pointermove',function (event) {
      if (event.pointerId===active) move(coordinates(event,canvas));
    });
    function finish(event) {
      if (event.pointerId!==active) return;
      active=null;
      if (end) end(event.type==='pointerup');
    }
    canvas.addEventListener('pointerup',finish);
    canvas.addEventListener('pointercancel',finish);
    canvas.addEventListener('lostpointercapture',finish);
  }
  function makeButton(label,fn,primary) {
    const b=document.createElement('button');
    b.type='button';
    b.className='button'+(primary?' primary':'');
    b.textContent=label;
    b.addEventListener('click',fn);
    return b;
  }
  function buttonRow(className) {
    const row=document.createElement('div');
    row.className=className;
    return row;
  }
  function normalize(file) {
    if (!file || (file.type && file.type.indexOf('image/')!==0)) return Promise.reject(new Error('请选择一张可以预览的图片。'));
    const source=URL.createObjectURL(file);
    return new Promise(function (resolve,reject) {
      const picture=new Image();
      picture.onload=function () {
        try {
          const scale=Math.min(1,1500/Math.max(picture.naturalWidth,picture.naturalHeight));
          const canvas=art.element(Math.max(1,Math.round(picture.naturalWidth*scale)),Math.max(1,Math.round(picture.naturalHeight*scale)));
          const ctx=canvas.getContext('2d');
          const alpha=file.type==='image/png' || file.type==='image/webp';
          if (!alpha) {ctx.fillStyle='#fffaf1';ctx.fillRect(0,0,canvas.width,canvas.height);}
          ctx.drawImage(picture,0,0,canvas.width,canvas.height);
          resolve(canvas.toDataURL(alpha?'image/png':'image/jpeg',.87));
        } catch (_) {reject(new Error('这张图片无法处理，可以换一张 JPG 或 PNG。'));}
        finally {URL.revokeObjectURL(source);}
      };
      picture.onerror=function () {
        URL.revokeObjectURL(source);
        reject(new Error('无法读取图片，可以先转换成 JPG 或 PNG。'));
      };
      picture.src=source;
    });
  }

  function markColor(source,mask,point,tolerance) {
    const w=source.width,h=source.height;
    const x=art.clamp(Math.floor(point[0]),0,w-1),y=art.clamp(Math.floor(point[1]),0,h-1);
    const pixels=source.getContext('2d').getImageData(0,0,w,h).data;
    const ctx=mask.getContext('2d');
    const output=ctx.getImageData(0,0,w,h);
    const seen=new Uint8Array(w*h), pending=new Int32Array(w*h);
    const start=y*w+x;
    const red=pixels[start*4],green=pixels[start*4+1],blue=pixels[start*4+2];
    const limit=tolerance*tolerance;
    let head=0,tail=1,changed=0;
    pending[0]=start;
    seen[start]=1;
    function queue(pixel) {
      if (seen[pixel]) return;
      seen[pixel]=1;
      const p=pixel*4;
      const dr=pixels[p]-red,dg=pixels[p+1]-green,db=pixels[p+2]-blue;
      if (dr*dr+dg*dg+db*db<=limit || pixels[p+3]===0) pending[tail++]=pixel;
    }
    while(head<tail) {
      const pixel=pending[head++];
      const p=pixel*4;
      if (output.data[p+3]!==255 && pixels[p+3]!==0) changed++;
      output.data[p+3]=255;
      const column=pixel%w;
      if (column>0) queue(pixel-1);
      if (column<w-1) queue(pixel+1);
      if (pixel>=w) queue(pixel-w);
      if (pixel<w*(h-1)) queue(pixel+w);
    }
    ctx.putImageData(output,0,0);
    return changed;
  }
  function composite(source,mask,into) {
    const ctx=into.getContext('2d');
    ctx.clearRect(0,0,into.width,into.height);
    ctx.drawImage(source,0,0);
    ctx.globalCompositeOperation='destination-out';
    ctx.drawImage(mask,0,0);
    ctx.globalCompositeOperation='source-over';
  }
  function stickerImage(canvas) {
    const w=canvas.width,h=canvas.height,pixels=canvas.getContext('2d').getImageData(0,0,w,h).data;
    let left=w,right=-1,top=h,bottom=-1;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
      if (pixels[(y*w+x)*4+3]<24) continue;
      left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
    }
    if (right<left || bottom<top) throw new Error('没有留下主体。可以点补回或重置。');
    const pad=11,sw=right-left+1,sh=bottom-top+1;
    const silhouette=art.element(sw,sh), sctx=silhouette.getContext('2d');
    sctx.drawImage(canvas,left,top,sw,sh,0,0,sw,sh);
    sctx.globalCompositeOperation='source-in';
    sctx.fillStyle='#fff9eb';sctx.fillRect(0,0,sw,sh);
    const output=art.element(sw+pad*2,sh+pad*2),ctx=output.getContext('2d');
    for (let i=0;i<14;i++) {
      const angle=i*Math.PI/7;
      ctx.drawImage(silhouette,pad+5*Math.cos(angle),pad+5*Math.sin(angle));
    }
    ctx.drawImage(canvas,left,top,sw,sh,pad,pad,sw,sh);
    return {data:output.toDataURL('image/png'),ratio:output.width/output.height};
  }

  function renderCrop(options) {
    const root=document.createElement('div');
    const message=document.createElement('p');
    message.className='modal-note';
    message.textContent=options.background
      ? '拖动或缩放，选好要铺满手账页的 3:4 区域。'
      : '先选样式，再拖动或缩放照片调整取景。';
    root.appendChild(message);

    const width=options.width || 1080,height=options.height || 1440;
    const previewScale=options.background?252/width:Math.min(290/width,335/height);
    const canvas=art.element(Math.round(width*previewScale),Math.round(height*previewScale));
    canvas.className='crop-stage'+(options.background?'':' crop-preview-frame');
    canvas.setAttribute('aria-label',options.background?'3:4 底图裁剪预览':'照片样式预览');
    root.appendChild(canvas);

    const bounds=options.sourceBox || [0,0,options.image.naturalWidth,options.image.naturalHeight];
    const crop=Object.assign({x:.5,y:.5,z:1},options.crop);
    let shape=labels[options.shape]?options.shape:'instant',start=null;
    const ctx=canvas.getContext('2d');

    function opening() {
      return options.background?{width:width,height:height}:art.photoOpening(shape,width,height);
    }
    function coverScale() {
      const frame=opening();
      return Math.max(frame.width/bounds[2],frame.height/bounds[3])*crop.z;
    }
    function render() {
      const frame=opening(), scale=coverScale();
      const minX=Math.min(.5,frame.width/scale/bounds[2]/2);
      const minY=Math.min(.5,frame.height/scale/bounds[3]/2);
      crop.x=art.clamp(crop.x,minX,1-minX);
      crop.y=art.clamp(crop.y,minY,1-minY);
      ctx.clearRect(0,0,canvas.width,canvas.height);
      if (options.background) {
        art.cover(ctx,options.image,0,0,canvas.width,canvas.height,crop,bounds);
        ctx.strokeStyle='rgba(255,255,255,.75)';
        for (let i=1;i<=2;i++) {
          ctx.beginPath();ctx.moveTo(canvas.width*i/3,0);ctx.lineTo(canvas.width*i/3,canvas.height);
          ctx.moveTo(0,canvas.height*i/3);ctx.lineTo(canvas.width,canvas.height*i/3);ctx.stroke();
        }
        return;
      }
      ctx.save();
      ctx.translate(canvas.width/2,canvas.height/2);
      ctx.scale(previewScale*.90,previewScale*.90);
      art.photoFrame(ctx,{w:width,h:height,shape:shape,crop:crop},options.image,bounds);
      ctx.restore();
    }

    if (!options.background) {
      const styles=buttonRow('crop-style-row');
      const buttons=Object.keys(labels).map(function (key) {
        const button=makeButton(labels[key],function () {shape=key;selectStyle();});
        button.dataset.shape=key;
        styles.appendChild(button);
        return button;
      });
      function selectStyle() {
        buttons.forEach(function (button) {
          const active=button.dataset.shape===shape;
          button.classList.toggle('active',active);
          button.setAttribute('aria-pressed',String(active));
        });
        render();
      }
      root.appendChild(styles);
      selectStyle();
    }

    const controls=buttonRow('crop-range');
    const label=document.createElement('label');
    label.htmlFor='crop-zoom';label.textContent='缩放';
    const zoom=document.createElement('input');
    zoom.type='range';zoom.min='100';zoom.max='300';zoom.id='crop-zoom';zoom.value=Math.round(crop.z*100);
    zoom.addEventListener('input',function () {crop.z=Number(zoom.value)/100;render();});
    controls.appendChild(label);controls.appendChild(zoom);root.appendChild(controls);
    bindDrag(canvas,function (point) {
      start={point:point,x:crop.x,y:crop.y};
    },function (point) {
      const scale=coverScale()*previewScale*(options.background?1:.90);
      crop.x=start.x-(point[0]-start.point[0])/scale/bounds[2];
      crop.y=start.y-(point[1]-start.point[1])/scale/bounds[3];
      render();
    },function () {start=null;});

    const actions=buttonRow('modal-actions');
    actions.appendChild(makeButton('取消',options.cancel));
    actions.appendChild(makeButton(options.background?'使用这张底图':'应用到页面',function () {
      options.apply({crop:Object.assign({},crop),shape:shape});
    },true));
    root.appendChild(actions);render();
    return root;
  }

  function imageHasTransparency(source) {
    const probe=art.element(32,32);
    const ctx=probe.getContext('2d');
    ctx.drawImage(source,0,0,32,32);
    const pixels=ctx.getImageData(0,0,32,32).data;
    let transparent=0;
    for(let i=3;i<pixels.length;i+=4) if(pixels[i]<24) transparent++;
    return transparent>51;
  }

  async function subjectMask(source,guide,alive) {
    const width=source.width,height=source.height;
    const size=guide?96:128;
    const region=guide?{
      left:Math.max(0,guide.left-guide.w*.15),top:Math.max(0,guide.top-guide.h*.15),
      right:Math.min(width,guide.left+guide.w*1.15),bottom:Math.min(height,guide.top+guide.h*1.15)
    }:{left:0,top:0,right:width,bottom:height};
    const sw=region.right-region.left,sh=region.bottom-region.top;
    const small=art.element(size,size),ctx=small.getContext('2d');
    ctx.drawImage(source,region.left,region.top,sw,sh,0,0,size,size);
    const prediction=await window.JournalSubject.predict(ctx.getImageData(0,0,size,size).data,size,alive);
    if(!alive()) return null;

    let low=1,high=0;
    for(let i=0;i<prediction.length;i++) {
      low=Math.min(low,prediction[i]);high=Math.max(high,prediction[i]);
    }
    if(high-low<.14 || high<.24) return null;
    const image=ctx.createImageData(size,size);
    let visible=0;
    for(let i=0;i<prediction.length;i++) {
      const confidence=(prediction[i]-low)/(high-low);
      const weight=art.clamp((confidence-.26)/.46,0,1);
      if(weight>.5) visible++;
      image.data[i*4+3]=Math.round(255*(1-weight*weight*(3-2*weight)));
    }
    if(visible<prediction.length*.007 || visible>prediction.length*.94) return null;
    ctx.putImageData(image,0,0);
    const output=art.element(width,height),draw=output.getContext('2d');
    if(guide) {
      draw.fillRect(0,0,width,height);
      draw.clearRect(guide.left,guide.top,guide.w,guide.h);
      draw.beginPath();draw.rect(guide.left,guide.top,guide.w,guide.h);draw.clip();
    }
    draw.drawImage(small,region.left,region.top,sw,sh);
    return output;
  }

  function renderCutout(options) {
    const root=document.createElement('div');
    const status=document.createElement('p');
    status.className='cutout-status';
    status.setAttribute('role','status');
    const bounds=options.sourceBox || [0,0,options.image.naturalWidth,options.image.naturalHeight];
    const scale=Math.min(1,620/Math.max(bounds[2],bounds[3]));
    const w=Math.max(1,Math.round(bounds[2]*scale)),h=Math.max(1,Math.round(bounds[3]*scale));
    const source=art.element(w,h), mask=art.element(w,h), canvas=art.element(w,h);
    source.getContext('2d').drawImage(options.image,bounds[0],bounds[1],bounds[2],bounds[3],0,0,w,h);
    canvas.className='crop-stage sticker-stage crop-checker';
    canvas.setAttribute('aria-label','抠图预览');
    root.appendChild(status);root.appendChild(canvas);

    const instruction=document.createElement('p');
    instruction.className='modal-note cutout-instruction';
    const automatic=buttonRow('cutout-heading'), tools=buttonRow('cutout-tools'), actions=buttonRow('modal-actions');
    const maskContext=mask.getContext('2d');
    const history=[];
    let mode='frame',edited=false,polygon=null,last=null,boxStart=null,boxEnd=null,busy=false;
    const guidance={
      frame:'拖出一个框，把你想保留的物体圈在框里。',
      outline:'用手指沿主体画一圈，松手后保留圈内。',
      color:'点一下背景，去掉相连的相近颜色。',
      erase:'在预览上涂掉多余的部分。',
      restore:'在预览上涂回想保留的部分。'
    };

    function paint() {composite(source,mask,canvas);}
    function checkpoint() {
      history.push({pixels:maskContext.getImageData(0,0,w,h),edited:edited});
      if(history.length>7) history.shift();
      undo.disabled=false;
    }
    function drawOutline() {
      const ctx=canvas.getContext('2d');
      ctx.clearRect(0,0,w,h);
      ctx.drawImage(source,0,0);
      if(polygon.length<2) return;
      ctx.strokeStyle='#fff7e7';ctx.lineWidth=6;ctx.lineJoin='round';
      ctx.beginPath();ctx.moveTo(polygon[0][0],polygon[0][1]);
      polygon.slice(1).forEach(function (p) {ctx.lineTo(p[0],p[1]);});
      ctx.stroke();
      ctx.strokeStyle='#a6513a';ctx.lineWidth=3;ctx.stroke();
    }
    function finishOutline() {
      if(polygon.length<4) {paint();return;}
      const xs=polygon.map(function (point) {return point[0];});
      const ys=polygon.map(function (point) {return point[1];});
      if((Math.max.apply(null,xs)-Math.min.apply(null,xs))*(Math.max.apply(null,ys)-Math.min.apply(null,ys))<w*h*.003) {
        paint();return;
      }
      checkpoint();
      maskContext.fillStyle='#000';maskContext.fillRect(0,0,w,h);
      maskContext.save();maskContext.globalCompositeOperation='destination-out';
      maskContext.beginPath();maskContext.moveTo(polygon[0][0],polygon[0][1]);
      polygon.slice(1).forEach(function (p) {maskContext.lineTo(p[0],p[1]);});
      maskContext.closePath();maskContext.fill();maskContext.restore();
      edited=true;status.textContent='已保留圈内主体。';paint();
    }
    function stroke(a,b) {
      maskContext.save();
      maskContext.globalCompositeOperation=mode==='restore'?'destination-out':'source-over';
      maskContext.strokeStyle='#000';maskContext.fillStyle='#000';
      const width=Math.max(7,Math.max(w,h)*.035);
      maskContext.lineWidth=width;maskContext.lineCap='round';
      if(a===b) {
        maskContext.beginPath();maskContext.arc(a[0],a[1],width/2,0,Math.PI*2);maskContext.fill();
      } else {
        maskContext.beginPath();maskContext.moveTo(a[0],a[1]);maskContext.lineTo(b[0],b[1]);maskContext.stroke();
      }
      maskContext.restore();edited=true;paint();
    }
    function showBox() {
      const ctx=canvas.getContext('2d');
      ctx.clearRect(0,0,w,h);ctx.drawImage(source,0,0);
      ctx.strokeStyle='#fff9eb';ctx.lineWidth=5;
      const right=boxEnd[0]-boxStart[0],bottom=boxEnd[1]-boxStart[1];
      ctx.strokeRect(boxStart[0],boxStart[1],right,bottom);
      ctx.strokeStyle='#a6513a';ctx.lineWidth=2;
      ctx.setLineDash([7,5]);ctx.strokeRect(boxStart[0],boxStart[1],right,bottom);ctx.setLineDash([]);
    }
    function finishBox() {
      const left=art.clamp(Math.min(boxStart[0],boxEnd[0]),0,w);
      const top=art.clamp(Math.min(boxStart[1],boxEnd[1]),0,h);
      const right=art.clamp(Math.max(boxStart[0],boxEnd[0]),0,w);
      const bottom=art.clamp(Math.max(boxStart[1],boxEnd[1]),0,h);
      if(right-left<12 || bottom-top<12) {
        status.textContent='请拖出一个能包住主体的框。';paint();return;
      }
      runAutomatic(true,{left:left,top:top,w:right-left,h:bottom-top});
    }
    function runAutomatic(keepPrevious,guide) {
      if(busy) return;
      busy=true;auto.disabled=true;apply.disabled=true;
      status.textContent=guide?'正在分离框内主体…':'正在识别照片主体…';
      const alive=function () {return document.contains(root);};
      requestAnimationFrame(function () {
        setTimeout(async function () {
          if(!alive()) return;
          try {
            const transparent=!guide && imageHasTransparency(source);
            const result=transparent?null:await subjectMask(source,guide,alive);
            if(!alive()) return;
            if(transparent || result) {
              if(keepPrevious) checkpoint();
              maskContext.clearRect(0,0,w,h);
              if(result) maskContext.drawImage(result,0,0);
              edited=true;
              status.textContent=transparent?'已保留原图的透明区域。':
                (guide?'已重新抠出框内主体。':'已识别主体。需要调整时，可以框选对象。');
            } else {
              status.textContent=guide?'框内主体不够明确，可以缩小范围或手动修边。':
                '这张照片的主体不够明确，试试框选想保留的物体。';
            }
          } catch (_) {
            if(alive()) status.textContent='自动识别暂不可用，可以展开手动修边。';
          } finally {
            if(alive()) {
              busy=false;auto.disabled=false;apply.disabled=false;paint();
            }
          }
        },0);
      });
    }

    const auto=makeButton('自动抠图',function () {runAutomatic(true);});
    const undo=makeButton('撤销',function () {
      if(busy || !history.length) return;
      const saved=history.pop();
      maskContext.putImageData(saved.pixels,0,0);edited=saved.edited;
      undo.disabled=!history.length;status.textContent='已撤销上一步修整。';paint();
    });
    undo.disabled=true;
    automatic.appendChild(auto);automatic.appendChild(undo);
    const fineTools=document.createElement('details');
    fineTools.className='editor-disclosure cutout-fine';
    const summary=document.createElement('summary');
    summary.textContent='手动修边';
    fineTools.appendChild(summary);fineTools.appendChild(tools);
    const frameButton=makeButton('框选主体',function () {mode='frame';syncTool();});
    frameButton.dataset.tool='frame';automatic.insertBefore(frameButton,undo);
    const modeButtons=[frameButton].concat([['outline','圈选主体'],['color','点背景'],['erase','擦除'],['restore','补回']].map(function (entry) {
      const button=makeButton(entry[1],function () {mode=entry[0];syncTool();});
      button.dataset.tool=entry[0];tools.appendChild(button);
      return button;
    }));
    function syncTool() {
      instruction.textContent=guidance[mode];
      modeButtons.forEach(function (button) {
        const active=button.dataset.tool===mode;
        button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
      });
    }
    bindDrag(canvas,function (p) {
      if(busy) return;
      if(mode==='frame') {boxStart=p;boxEnd=p;showBox();return;}
      if(mode==='outline') {polygon=[p];drawOutline();return;}
      checkpoint();
      if(mode==='color') {
        if(markColor(source,mask,p,52)) {edited=true;paint();}
      } else {last=p;stroke(p,p);}
    },function (p) {
      if(boxStart) {boxEnd=p;showBox();}
      else if(polygon) {polygon.push(p);drawOutline();}
      else if(last) {stroke(last,p);last=p;}
    },function (completed) {
      if(boxStart && completed) finishBox();
      else if(polygon && completed) finishOutline();
      else if(polygon || boxStart) paint();
      boxStart=null;boxEnd=null;polygon=null;last=null;
    });
    actions.appendChild(makeButton('取消',options.cancel));
    const apply=makeButton('贴到手账',function () {
      try {
        if(!edited) throw new Error('请先框选主体，或展开手动修边。');
        options.apply({sticker:stickerImage(canvas),mask:mask.toDataURL('image/png')});
      } catch (error) {options.onError(error.message);}
    },true);
    actions.appendChild(apply);
    root.appendChild(automatic);root.appendChild(instruction);root.appendChild(fineTools);root.appendChild(actions);
    syncTool();
    if(options.savedMask) {
      maskContext.drawImage(options.savedMask,0,0,w,h);
      status.textContent='继续修整这张贴纸。';edited=true;paint();
    } else {
      paint();
      runAutomatic(false);
    }
    return root;
  }

  window.JournalCrop={normalize:normalize,render:renderCrop,renderCutout:renderCutout};
})();
