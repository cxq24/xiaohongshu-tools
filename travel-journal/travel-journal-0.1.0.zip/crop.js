(function () {
  'use strict';
  const art=window.JournalArt;
  const labels={instant:'拍立得',tear:'撕纸边',stamp:'邮票边',round:'圆形',ticket:'票据卡'};
  function coordinates(event,canvas) {
    const rect=canvas.getBoundingClientRect();
    return [(event.clientX-rect.left)*canvas.width/rect.width,(event.clientY-rect.top)*canvas.height/rect.height];
  }
  function bindDrag(canvas,begin,move,end) {
    let active=null;
    canvas.addEventListener('pointerdown',function (event) {
      if (active!==null || event.button!==0) return;
      event.preventDefault();
      active=event.pointerId;
      canvas.setPointerCapture(active);
      begin(coordinates(event,canvas));
    });
    canvas.addEventListener('pointermove',function (event) {
      if (event.pointerId===active) move(coordinates(event,canvas));
    });
    function finish(event) {
      if (event.pointerId!==active) return;
      active=null;
      if (end) end();
    }
    canvas.addEventListener('pointerup',finish);
    canvas.addEventListener('pointercancel',finish);
    canvas.addEventListener('lostpointercapture',finish);
  }
  function makeButton(label,fn,primary) {
    const b=document.createElement('button');
    b.type='button';
    b.className='button'+(primary?' primary':'');
    b.textContent=label;
    b.addEventListener('click',fn);
    return b;
  }
  function buttonRow(className) {
    const row=document.createElement('div');
    row.className=className;
    return row;
  }
  function normalize(file) {
    if (!file || (file.type && file.type.indexOf('image/')!==0)) return Promise.reject(new Error('请选择一张可以预览的图片。'));
    const source=URL.createObjectURL(file);
    return new Promise(function (resolve,reject) {
      const picture=new Image();
      picture.onload=function () {
        try {
          const scale=Math.min(1,1500/Math.max(picture.naturalWidth,picture.naturalHeight));
          const canvas=art.element(Math.max(1,Math.round(picture.naturalWidth*scale)),Math.max(1,Math.round(picture.naturalHeight*scale)));
          const ctx=canvas.getContext('2d');
          const alpha=file.type==='image/png' || file.type==='image/webp';
          if (!alpha) {ctx.fillStyle='#fffaf1';ctx.fillRect(0,0,canvas.width,canvas.height);}
          ctx.drawImage(picture,0,0,canvas.width,canvas.height);
          resolve(canvas.toDataURL(alpha?'image/png':'image/jpeg',.87));
        } catch (_) {reject(new Error('这张图片无法处理，可以换一张 JPG 或 PNG。'));}
        finally {URL.revokeObjectURL(source);}
      };
      picture.onerror=function () {
        URL.revokeObjectURL(source);
        reject(new Error('无法读取图片，可以先转换成 JPG 或 PNG。'));
      };
      picture.src=source;
    });
  }

  function markColor(source,mask,point,tolerance) {
    const w=source.width,h=source.height;
    const x=art.clamp(Math.floor(point[0]),0,w-1),y=art.clamp(Math.floor(point[1]),0,h-1);
    const pixels=source.getContext('2d').getImageData(0,0,w,h).data;
    const ctx=mask.getContext('2d');
    const output=ctx.getImageData(0,0,w,h);
    const seen=new Uint8Array(w*h), pending=new Int32Array(w*h);
    const start=y*w+x;
    const red=pixels[start*4],green=pixels[start*4+1],blue=pixels[start*4+2];
    const limit=tolerance*tolerance;
    let head=0,tail=1,changed=0;
    pending[0]=start;
    seen[start]=1;
    function queue(pixel) {
      if (seen[pixel]) return;
      seen[pixel]=1;
      const p=pixel*4;
      const dr=pixels[p]-red,dg=pixels[p+1]-green,db=pixels[p+2]-blue;
      if (dr*dr+dg*dg+db*db<=limit || pixels[p+3]===0) pending[tail++]=pixel;
    }
    while(head<tail) {
      const pixel=pending[head++];
      const p=pixel*4;
      if (output.data[p+3]!==255 && pixels[p+3]!==0) changed++;
      output.data[p+3]=255;
      const column=pixel%w;
      if (column>0) queue(pixel-1);
      if (column<w-1) queue(pixel+1);
      if (pixel>=w) queue(pixel-w);
      if (pixel<w*(h-1)) queue(pixel+w);
    }
    ctx.putImageData(output,0,0);
    return changed;
  }
  function composite(source,mask,into) {
    const ctx=into.getContext('2d');
    ctx.clearRect(0,0,into.width,into.height);
    ctx.drawImage(source,0,0);
    ctx.globalCompositeOperation='destination-out';
    ctx.drawImage(mask,0,0);
    ctx.globalCompositeOperation='source-over';
  }
  function stickerImage(canvas) {
    const w=canvas.width,h=canvas.height,pixels=canvas.getContext('2d').getImageData(0,0,w,h).data;
    let left=w,right=-1,top=h,bottom=-1;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
      if (pixels[(y*w+x)*4+3]<24) continue;
      left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
    }
    if (right<left || bottom<top) throw new Error('没有留下主体。可以点补回或重置。');
    const pad=11,sw=right-left+1,sh=bottom-top+1;
    const silhouette=art.element(sw,sh), sctx=silhouette.getContext('2d');
    sctx.drawImage(canvas,left,top,sw,sh,0,0,sw,sh);
    sctx.globalCompositeOperation='source-in';
    sctx.fillStyle='#fff9eb';sctx.fillRect(0,0,sw,sh);
    const output=art.element(sw+pad*2,sh+pad*2),ctx=output.getContext('2d');
    for (let i=0;i<14;i++) {
      const angle=i*Math.PI/7;
      ctx.drawImage(silhouette,pad+5*Math.cos(angle),pad+5*Math.sin(angle));
    }
    ctx.drawImage(canvas,left,top,sw,sh,pad,pad,sw,sh);
    return {data:output.toDataURL('image/png'),ratio:output.width/output.height};
  }

  function renderCrop(options) {
    const root=document.createElement('div');
    const note=document.createElement('p');
    note.className='modal-note';
    const canvas=art.element(360,Math.round(360/options.ratio));
    canvas.className='crop-stage';
    canvas.setAttribute('aria-label','图片裁剪预览');
    const nav=buttonRow('crop-nav'),tools=buttonRow('crop-controls'),actions=buttonRow('modal-actions');
    const rangeRow=buttonRow('crop-range');
    const zoomLabel=document.createElement('label');
    zoomLabel.htmlFor='crop-zoom';zoomLabel.textContent='缩放';
    const zoom=document.createElement('input');
    zoom.id='crop-zoom';zoom.type='range';zoom.min='100';zoom.max='300';
    rangeRow.appendChild(zoomLabel);rangeRow.appendChild(zoom);
    root.appendChild(note);root.appendChild(nav);root.appendChild(canvas);root.appendChild(rangeRow);root.appendChild(tools);root.appendChild(actions);
    const image=options.image;
    const bounds=options.sourceBox || [0,0,image.naturalWidth,image.naturalHeight];
    let crop=Object.assign({x:.5,y:.5,z:1},options.crop);
    let shape=options.shape || 'instant';
    let mode='frame', brush='color', source=null, mask=null, maskStack=[];
    let start=null, last=null, edited=false;
    let frameWidth=canvas.width,frameHeight=canvas.height;
    const brushButtons={};

    function normalizeCrop() {
      const scale=Math.max(frameWidth/bounds[2],frameHeight/bounds[3])*crop.z;
      const minX=frameWidth/scale/bounds[2]/2,minY=frameHeight/scale/bounds[3]/2;
      crop.x=art.clamp(crop.x,minX,1-minX);crop.y=art.clamp(crop.y,minY,1-minY);
    }
    function renderFrame() {
      normalizeCrop();
      const ctx=canvas.getContext('2d');
      ctx.clearRect(0,0,canvas.width,canvas.height);
      art.cover(ctx,image,0,0,canvas.width,canvas.height,crop,bounds);
      ctx.strokeStyle='rgba(255,255,255,0.6902)';ctx.lineWidth=1;
      for(let i=1;i<=2;i++) {
        ctx.beginPath();ctx.moveTo(canvas.width*i/3,0);ctx.lineTo(canvas.width*i/3,canvas.height);
        ctx.moveTo(0,canvas.height*i/3);ctx.lineTo(canvas.width,canvas.height*i/3);ctx.stroke();
      }
    }
    function updateNote() {
      if (mode==='frame') note.textContent=options.background
        ? '拖动图片调整取景，确认后按 3:4 铺满整页。'
        : '拖动和缩放照片，选好想保留的画面。';
      else if (brush==='color') note.textContent='点一下颜色相近、相连的背景。复杂边缘可以用擦除和补回调整。';
      else note.textContent=brush==='erase'?'在预览里涂掉背景和多余边缘。':'在预览里涂回想保留的部分。';
    }
    function setBrush(next) {
      brush=next;updateNote();
      Object.keys(brushButtons).forEach(function (key) {brushButtons[key].classList.toggle('active',key===brush);});
    }
    function rememberMask() {
      maskStack.push({pixels:mask.getContext('2d').getImageData(0,0,mask.width,mask.height),edited:edited});
      if(maskStack.length>7) maskStack.shift();
    }
    function renderSticker() { composite(source,mask,canvas); }
    function switchMode(next) {
      mode=next;
      canvas.classList.toggle('sticker-stage',mode==='sticker');
      canvas.classList.toggle('crop-checker',mode==='sticker');
      rangeRow.hidden=mode==='sticker';
      tools.textContent='';
      if (mode==='sticker') {
        const scale=Math.min(1,555/Math.max(bounds[2],bounds[3]));
        canvas.width=Math.max(1,Math.round(bounds[2]*scale));canvas.height=Math.max(1,Math.round(bounds[3]*scale));
        if (!source) {
          source=art.element(canvas.width,canvas.height);mask=art.element(canvas.width,canvas.height);
          source.getContext('2d').drawImage(image,bounds[0],bounds[1],bounds[2],bounds[3],0,0,canvas.width,canvas.height);
        }
        brushButtons.color=makeButton('点选去背景',function(){setBrush('color');});
        brushButtons.erase=makeButton('擦除',function(){setBrush('erase');});
        brushButtons.restore=makeButton('补回',function(){setBrush('restore');});
        Object.keys(brushButtons).forEach(function (key) {tools.appendChild(brushButtons[key]);});
        tools.appendChild(makeButton('撤销',function () {
          const previous=maskStack.pop();
          if (!previous) return;
          mask.getContext('2d').putImageData(previous.pixels,0,0);edited=previous.edited;renderSticker();
        }));
        tools.appendChild(makeButton('重置',function () {
          rememberMask();mask.getContext('2d').clearRect(0,0,mask.width,mask.height);edited=false;renderSticker();
        }));
        setBrush(brush);renderSticker();
      } else {
        canvas.width=frameWidth;canvas.height=frameHeight;
        if (!options.background) Object.keys(labels).forEach(function (key) {
          const button=makeButton(labels[key],function () {
            shape=key;
            Array.from(tools.children).forEach(function (b) {b.classList.toggle('active',b===button);});
          });
          button.classList.toggle('active',shape===key);
          tools.appendChild(button);
        });
        renderFrame();
      }
      Array.from(nav.children).forEach(function (button) {button.classList.toggle('active',button.dataset.mode===mode);});
      updateNote();
    }
    if (!options.background) {
      [['frame','裁成照片卡'],['sticker','剪成贴纸']].forEach(function (option) {
        const b=makeButton(option[1],function () {switchMode(option[0]);});
        b.dataset.mode=option[0];
        nav.appendChild(b);
      });
    } else nav.hidden=true;
    zoom.value=Math.round(crop.z*100);
    zoom.addEventListener('input',function () {crop.z=Number(zoom.value)/100;renderFrame();});
    function stroke(a,b) {
      const ctx=mask.getContext('2d');
      ctx.save();
      ctx.globalCompositeOperation=brush==='restore'?'destination-out':'source-over';
      ctx.strokeStyle='#000';ctx.fillStyle='#000';ctx.lineWidth=Math.max(13,canvas.width*.045);ctx.lineCap='round';
      if (a[0]===b[0] && a[1]===b[1]) {ctx.beginPath();ctx.arc(a[0],a[1],ctx.lineWidth/2,0,Math.PI*2);ctx.fill();}
      else {ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}
      ctx.restore();
      edited=true;renderSticker();
    }
    bindDrag(canvas,function (point) {
      if (mode==='frame') {start={point:point,crop:Object.assign({},crop)};return;}
      rememberMask();
      if(brush==='color') {
        if(markColor(source,mask,point,52)) {edited=true;renderSticker();}
      } else {last=point;stroke(point,point);}
    },function (point) {
      if (mode==='frame') {
        if (!start) return;
        const scale=Math.max(frameWidth/bounds[2],frameHeight/bounds[3])*crop.z;
        crop.x=start.crop.x-(point[0]-start.point[0])/scale/bounds[2];
        crop.y=start.crop.y-(point[1]-start.point[1])/scale/bounds[3];
        renderFrame();
      } else if (last && brush!=='color') {stroke(last,point);last=point;}
    }, function () {start=null;last=null;});
    actions.appendChild(makeButton('取消',options.cancel));
    actions.appendChild(makeButton(options.background?'使用这张底图':'应用到页面',function () {
      try {
        if(mode==='sticker') {
          const input=source.getContext('2d').getImageData(0,0,source.width,source.height).data;
          let transparent=false;
          for (let i=3;i<input.length;i+=4) {if (input[i]<128) {transparent=true;break;}}
          if (!edited && !transparent) throw new Error('先点选背景或擦除一部分图片，再保存贴纸。');
          options.apply({mode:mode,sticker:stickerImage(canvas)});
        } else options.apply({mode:mode,crop:Object.assign({},crop),shape:shape});
      } catch (error) {options.onError(error.message);}
    },true));
    switchMode(options.startSticker?'sticker':'frame');
    return root;
  }
  window.JournalCrop={normalize:normalize,render:renderCrop};
})();
