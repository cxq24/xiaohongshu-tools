(function () {
  'use strict';

  const catalog=window.JournalCatalog;
  const art=window.JournalArt;
  const cropper=window.JournalCrop;
  const platform=window.JournalStore;
  const store=platform.create();
  const $=function (id) {return document.getElementById(id);};
  const canvas=$('page-canvas');
  const W=art.W,H=art.H;
  const state={
    view:'editor',panel:'layout',page:null,assets:{},selected:'',saved:null,bookHint:'',
    reader:{bookId:'',index:0},undo:[],redo:[],dirty:false,fieldKey:'',slotHint:-1,
    modalOpen:false,modalBusy:false,loadingStore:true,storageError:''
  };
  let toastTimer,paintFrame=0,readerStart=null,drag=null,modalFocus=null;
  const readingFoot=$('reader-page-title');
  const demoInfo={title:'水乡慢慢走',city:'江南',date:'2026-10-18',caption:'沿着河走，看到一座桥就停一停。'};

  function icon(name) {
    return '<span data-icon="'+name+'" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true">'+(catalog.icons[name] || '')+'</svg></span>';
  }
  function labelIcons(root) {
    root.querySelectorAll('[data-icon]').forEach(function (element) {
      element.setAttribute('aria-hidden','true');
      element.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true">'+(catalog.icons[element.dataset.icon] || '')+'</svg>';
    });
  }
  function node(tag,className,content) {
    const element=document.createElement(tag);
    if(className) element.className=className;
    if(content!==undefined) element.textContent=content;
    return element;
  }
  function button(label,action,className,iconName) {
    const element=node('button',className || 'button');
    element.type='button';
    if(iconName) element.innerHTML=icon(iconName);
    if(label) element.appendChild(document.createTextNode(label));
    if(action) element.addEventListener('click',function () {return run(element,action);});
    return element;
  }
  function toast(message) {
    clearTimeout(toastTimer);
    $('toast').textContent=message;
    $('toast').hidden=false;
    toastTimer=setTimeout(function () {$('toast').hidden=true;},2600);
  }
  function report(error) {toast(platform.errorText(error));}
  async function run(element,operation) {
    if (element && element.disabled) return;
    if (element) element.disabled=true;
    try {await operation();}
    catch (error) {report(error);}
    finally {
      if (element && document.contains(element)) element.disabled=false;
      updateHistory();
    }
  }

  function today() {
    const date=new Date();
    const pad=function (x) {return ('0'+x).slice(-2);};
    return date.getFullYear()+'-'+pad(date.getMonth()+1)+'-'+pad(date.getDate());
  }
  function getLayout(id) {
    return catalog.layouts.find(function (l) {return l.id===id;}) || catalog.layouts[2];
  }
  function decorItem(id,demo) {
    const sizes={ticket:[244,111],tape:[190,39],stamp:[164,164],note:[288,114],route:[265,112],spark:[90,90]};
    const size=sizes[id];
    return {id:platform.id(),kind:'decor',type:id,x:W*.59,y:H*.60,w:size[0],h:size[1],
      scale:1,rotation:id==='ticket'?-8:0,text:id==='note'?'今天的小事':'',demo:!!demo};
  }
  function spillSlot(index) {
    const i=index%12;
    return [.30+(i%3)*.20,.34+Math.floor(i/3)*.12,.34,.24,[-8,4,9,0][i%4],'instant'];
  }
  function place(item,slot) {
    item.x=slot[0]*W;item.y=slot[1]*H;item.w=slot[2]*W;item.h=slot[3]*H;item.rotation=slot[4];item.scale=1;
  }
  function makePhoto(id,slot,slotIndex,demo) {
    const item={id:platform.id(),kind:'photo',asset:id,shape:slot[5],slot:slotIndex,crop:{x:.5,y:.5,z:1},demo:!!demo};
    place(item,slot);
    return item;
  }
  function sample() {
    const page=Object.assign({layout:'triple',paper:'kraft',background:null,items:[],sample:true},demoInfo);
    page.items=art.sampleIds.map(function (asset,i) {return makePhoto(asset,getLayout('triple').slots[i],i,true);});
    const tape=decorItem('tape',true);
    Object.assign(tape,{x:438,y:344,rotation:8,w:187});
    const ticket=decorItem('ticket',true);
    Object.assign(ticket,{x:280,y:1102,rotation:-9});
    const route=decorItem('route',true);
    Object.assign(route,{x:624,y:1117,rotation:2,w:242});
    const stamp=decorItem('stamp',true);
    Object.assign(stamp,{x:884,y:293,rotation:14});
    const star=decorItem('spark',true);
    Object.assign(star,{x:927,y:1084,rotation:2});
    page.items.push(tape,ticket,route,stamp,star);
    return page;
  }
  function blank() {return {title:'',city:'',date:today(),caption:'',layout:'triple',paper:'kraft',background:null,items:[],sample:false};}
  function setPage(page,assets,saved,bookHint) {
    state.page=page;state.assets=assets || {};state.selected='';state.undo=[];state.redo=[];
    state.saved=saved || null;state.bookHint=bookHint || '';state.dirty=false;state.fieldKey='';
    syncEditor();
  }
  function editableItem() {
    return state.page.items.find(function (item) {return item.id===state.selected;});
  }
  function assetsFor(page) {
    const output={};
    art.assetIDs(page).forEach(function (id) {if(state.assets[id]) output[id]=state.assets[id];});
    return output;
  }
  function pruneAssets() {
    const ids=new Set();
    [state.page].concat(state.undo,state.redo).forEach(function (page) {
      art.assetIDs(page).forEach(function (id) {ids.add(id);});
    });
    Object.keys(state.assets).forEach(function (id) {if(!ids.has(id)) delete state.assets[id];});
  }
  function checkpoint() {
    state.undo.push(platform.copy(state.page));
    if(state.undo.length>15) state.undo.shift();
    state.redo=[];
    state.dirty=true;
    pruneAssets();
    updateHistory();
  }
  function changeField(key,update) {
    if(state.fieldKey!==key) {checkpoint();state.fieldKey=key;}
    update();
    paint();
  }
  function turnHistory(back) {
    const working=back?state.undo:state.redo;
    const opposite=back?state.redo:state.undo;
    if (!working.length) return;
    opposite.push(platform.copy(state.page));
    state.page=working.pop();
    state.fieldKey='';
    state.dirty=true;
    if(!editableItem()) state.selected='';
    syncEditor();
  }
  function updateHistory() {
    $('undo').disabled=!state.undo.length;
    $('redo').disabled=!state.redo.length;
  }

  function missingSlots() {
    const occupied=new Set();
    state.page.items.forEach(function (item) {if(item.kind==='photo') occupied.add(item.slot);});
    const output=[];
    getLayout(state.page.layout).slots.forEach(function (slot,index) {if(!occupied.has(index)) output.push({slot:slot,index:index});});
    return output;
  }
  function renderSlots() {
    const root=$('photo-slots');
    root.textContent='';
    missingSlots().forEach(function (entry) {
      const slot=entry.slot;
      const add=button('',function () {importPhotos(entry.index);},'slot-button','plus');
      add.setAttribute('aria-label','导入第 '+(entry.index+1)+' 张照片');
      add.style.left=(slot[0]-slot[2]/2)*100+'%';add.style.top=(slot[1]-slot[3]/2)*100+'%';
      add.style.width=slot[2]*100+'%';add.style.height=slot[3]*100+'%';add.style.transform='rotate('+slot[4]+'deg)';
      root.appendChild(add);
    });
    root.hidden=!!editableItem();
  }
  function paint() {
    if(paintFrame) return;
    paintFrame=requestAnimationFrame(function () {
      paintFrame=0;
      art.draw(canvas,state.page,state.assets,{slots:missingSlots().map(function (entry) {return entry.slot;}),selected:state.selected,onReady:paint});
      $('canvas-title').textContent=state.page.title || '未命名手账页';
      document.querySelector('.studio-kicker').textContent=state.page.sample?'示例页面':'当前页面';
    });
  }
  function updateLayoutChoices() {
    $('layout-list').querySelectorAll('[data-layout]').forEach(function (option) {
      const active=option.dataset.layout===state.page.layout;
      option.classList.toggle('active',active);option.setAttribute('aria-pressed',String(active));
    });
  }
  function updatePaperChoices() {
    $('paper-list').querySelectorAll('[data-paper]').forEach(function (option) {
      const active=option.dataset.paper===state.page.paper;
      option.classList.toggle('active',active);option.setAttribute('aria-pressed',String(active));
    });
    $('background-controls').hidden=!state.page.background;
    if(state.page.background) $('background-opacity').value=Math.round(state.page.background.opacity*100);
  }
  function updateInspector() {
    const selected=editableItem();
    $('item-inspector').hidden=!selected;
    $('photo-slots').hidden=!!selected;
    canvas.style.cursor=selected?'grab':'default';
    if(!selected) return;
    $('item-title').textContent=selected.kind==='photo'?(selected.shape==='cutout'?'照片贴纸':'照片'):catalog.decor.find(function (item) {return item.id===selected.type;}).label;
    $('edit-crop').hidden=selected.kind!=='photo';
    $('item-text-wrap').hidden=selected.type!=='note';
    if(selected.type==='note') $('item-text').value=selected.text;
    $('item-scale').value=Math.round(selected.scale*100);
    $('item-rotation').value=Math.round(selected.rotation);
  }
  function syncEditor() {
    ['title','city','date','caption'].forEach(function (key) { $('page-'+key).value=state.page[key]; });
    updateLayoutChoices();updatePaperChoices();renderSlots();updateInspector();updateHistory();paint();
  }
  function applyLayout(layout) {
    if(state.page.layout===layout.id) return;
    checkpoint();
    state.page.layout=layout.id;
    const photos=state.page.items.filter(function (item) {return item.kind==='photo';});
    photos.forEach(function (item,index) {
      const slot=layout.slots[index] || spillSlot(index);
      item.slot=index;
      place(item,slot);
      if(item.shape!=='cutout') item.shape=slot[5];
    });
    state.selected='';
    syncEditor();
  }
  function setPanel(panel) {
    state.panel=panel;
    ['layout','paper','decor'].forEach(function (key) {$(key+'-panel').hidden=key!==panel;});
    document.querySelectorAll('[data-panel]').forEach(function (option) {
      const active=option.dataset.panel===panel;
      option.classList.toggle('active',active);option.setAttribute('aria-selected',String(active));
    });
  }
  function createOptions() {
    catalog.layouts.forEach(function (layout) {
      const control=button('',function () {applyLayout(layout);},'choice');
      control.dataset.layout=layout.id;
      const icon=node('span','layout-thumb');
      (layout.slots.length?layout.slots:[[.39,.46,.37,.31,-12],[.65,.65,.34,.22,8]]).forEach(function (slot) {
        const box=node('i');
        box.style.left=(slot[0]-slot[2]/2)*100+'%';box.style.top=(slot[1]-slot[3]/2)*100+'%';
        box.style.width=slot[2]*100+'%';box.style.height=slot[3]*100+'%';
        box.style.transform='rotate('+slot[4]+'deg)';
        icon.appendChild(box);
      });
      control.appendChild(icon);control.appendChild(document.createTextNode(layout.name));
      $('layout-list').appendChild(control);
    });
    catalog.papers.forEach(function (paper) {
      const control=button('',function () {
        if(state.page.paper===paper.id && !state.page.background) return;
        checkpoint();state.page.paper=paper.id;state.page.background=null;updatePaperChoices();paint();
      },'choice paper-choice');
      control.dataset.paper=paper.id;
      const swatch=node('span','paper-swatch');
      swatch.style.backgroundColor=paper.base;swatch.style.backgroundImage=catalog.paperPreviews[paper.id];
      if(paper.id==='dots') swatch.style.backgroundSize='6px 6px';
      control.appendChild(swatch);control.appendChild(document.createTextNode(paper.name));
      $('paper-list').appendChild(control);
    });
    catalog.decor.forEach(function (decor) {
      const control=button('',function () {
        if(state.page.items.length>=40) {toast('这一页的素材已经很多，可以新建下一页。');return;}
        checkpoint();
        const item=decorItem(decor.id);
        state.page.items.push(item);state.selected=item.id;
        updateInspector();paint();
      },'choice decor-choice');
      const symbol=node('span','',decor.symbol);
      symbol.style.color=decor.color;symbol.setAttribute('aria-hidden','true');
      control.appendChild(symbol);control.appendChild(document.createTextNode(decor.label));$('decor-list').appendChild(control);
    });
  }

  function showView(view) {
    state.view=view;
    ['editor','library','reader'].forEach(function (key) {$(key+'-view').hidden=key!==view;});
    document.querySelectorAll('[data-view]').forEach(function (option) {
      const active=option.dataset.view===(view==='reader'?'library':view);
      option.classList.toggle('active',active);
      if(active) option.setAttribute('aria-current','page');
      else option.removeAttribute('aria-current');
    });
    if(view==='library') renderLibrary();
    if(view==='reader') renderReader();
    if(view==='editor') paint();
    window.scrollTo(0,0);
  }
  function newPage(bookHint) {
    if(state.dirty && !window.confirm('还没有保存这页，开始新的一页？')) return;
    setPage(blank(),{},null,bookHint);
    showView('editor');
  }
  function openModal(title,content) {
    modalFocus=document.activeElement;
    state.modalOpen=true;
    $('modal-title').textContent=title;
    $('modal-body').textContent='';
    $('modal-body').appendChild(content);
    $('modal-layer').hidden=false;
    $('modal').scrollTop=0;
    $('modal').focus();
  }
  function closeModal() {
    if(state.modalBusy) return;
    state.modalOpen=false;
    $('modal-layer').hidden=true;
    $('modal-body').textContent='';
    if(modalFocus && document.contains(modalFocus)) modalFocus.focus();
  }
  function messageDialog(title,description) {
    const body=node('div');
    body.appendChild(node('p','modal-note',description));
    const actions=node('div','modal-actions');
    actions.appendChild(button('知道了',closeModal,'button primary'));
    body.appendChild(actions);openModal(title,body);
  }
  function setModalBusy(busy) {
    state.modalBusy=busy;
    const dismiss=$('modal').querySelector('[data-action="close-modal"]');
    if (dismiss) dismiss.disabled=busy;
  }

  function importPhotos(slot) {
    state.slotHint=typeof slot==='number'?slot:-1;
    $('photo-input').click();
  }
  async function addPhotos(files) {
    if(!files.length) return;
    const target=state.page;
    const existing=target.items.filter(function (item) {return !item.demo && item.kind==='photo';}).length;
    const currentItems=target.items.filter(function (item) {return !item.demo;}).length;
    const allowed=Math.min(18-existing,40-currentItems);
    if(allowed<=0) {toast('这一页已经有很多素材，可以放到下一页。');return;}
    const slotHint=state.slotHint;
    $('loading-art').hidden=false;
    const loaded=[];
    let failed=0;
    try {
      for(const file of files.slice(0,allowed)) {
        try {
          const source=await cropper.normalize(file);
          const record=art.imageRecord(source);
          if(!await record.done) throw new Error('图片读取失败');
          loaded.push(source);
        } catch (_) {failed++;}
      }
      if(state.page!==target) return;
      if(!loaded.length) throw new Error('无法读取所选图片，可以先转换成 JPG 或 PNG。');
      checkpoint();
      if(state.page.sample) {
        state.page.sample=false;
        state.page.items=state.page.items.filter(function (item) {return !item.demo;});
        Object.keys(demoInfo).forEach(function (key) {
          if(state.page[key]===demoInfo[key]) state.page[key]=key==='date'?today():'';
        });
      }
      const used=new Set(state.page.items.filter(function (item) {return item.kind==='photo';}).map(function (item) {return item.slot;}));
      const spots=getLayout(state.page.layout).slots;
      const added=[];
      loaded.forEach(function (source,index) {
        const id='a-'+platform.id();
        state.assets[id]=source;
        let slotIndex=index===0 && slotHint>=0 && !used.has(slotHint)?slotHint:0;
        while(used.has(slotIndex)) slotIndex++;
        used.add(slotIndex);
        const item=makePhoto(id,spots[slotIndex] || spillSlot(slotIndex),slotIndex,false);
        state.page.items.push(item);added.push(item);
      });
      state.selected=added.length===1?added[0].id:'';
      syncEditor();
      if(failed || files.length>allowed) toast('已导入 '+loaded.length+' 张，部分图片超出本页数量或无法读取。');
      else toast('已导入 '+loaded.length+' 张照片');
    } finally {
      $('loading-art').hidden=true;
    }
  }
  async function openBackground(file) {
    if (!file) return;
    const target=state.page;
    const photo=await cropper.normalize(file);
    const image=await art.imageRecord(photo).done;
    if(!image) throw new Error('无法读取这张底图。');
    if(target!==state.page) return;
    openModal('裁剪手账底图',cropper.render({
      image:image,ratio:3/4,background:true,cancel:closeModal,onError:toast,
      apply:function (result) {
        checkpoint();
        const id='a-'+platform.id();
        state.assets[id]=photo;
        state.page.background={asset:id,opacity:.72,crop:result.crop};
        setPanel('paper');updatePaperChoices();closeModal();paint();
      }
    }));
  }
  async function openPhotoCrop() {
    const item=editableItem();
    if(!item || item.kind!=='photo') return;
    const id=item.originalAsset || item.asset;
    const source=art.sourceFor(id,state.assets);
    const record=art.imageRecord(source);
    const image=record && await record.done;
    if(!image || item!==editableItem()) throw new Error('这张照片暂时无法读取。');
    const original=item.original || {w:item.w,h:item.h,shape:item.shape};
    const ratio=Math.max(.35,original.w-24)/Math.max(.35,original.h-(original.shape==='instant'?65:24));
    openModal('编辑照片素材',cropper.render({
      image:image,ratio:art.clamp(ratio,.44,2.25),shape:original.shape,
      crop:item.crop,sourceBox:art.sourceBox(image,id),startSticker:item.shape==='cutout',
      cancel:closeModal,onError:toast,apply:function (result) {
        checkpoint();
        if(result.mode==='sticker') {
          const asset='a-'+platform.id();
          state.assets[asset]=result.sticker.data;
          item.original=original;item.originalAsset=id;item.asset=asset;item.shape='cutout';
          const max=Math.max(original.w,original.h);
          item.w=result.sticker.ratio>=1?max:max*result.sticker.ratio;
          item.h=result.sticker.ratio>=1?max/result.sticker.ratio:max;
        } else {
          item.asset=id;delete item.originalAsset;delete item.original;
          item.w=original.w;item.h=original.h;item.shape=result.shape;item.crop=result.crop;
        }
        closeModal();syncEditor();
      }
    }));
  }

  function point(event) {
    const rect=canvas.getBoundingClientRect();
    return [(event.clientX-rect.left)*W/rect.width,(event.clientY-rect.top)*H/rect.height];
  }
  function hitPage(event) {
    if(event.button!==0 || drag) return;
    const p=point(event);
    const selected=state.page.items.slice().reverse().find(function (item) {return art.hit(item,p[0],p[1]);});
    state.selected=selected?selected.id:'';
    state.fieldKey='';
    updateInspector();paint();
    if(!selected) return;
    canvas.setPointerCapture(event.pointerId);
    drag={pointer:event.pointerId,origin:p,offset:[selected.x,selected.y],item:selected,started:false};
    canvas.style.cursor='grabbing';
  }
  function movePage(event) {
    if(!drag || drag.pointer!==event.pointerId) return;
    const p=point(event);
    const dx=p[0]-drag.origin[0],dy=p[1]-drag.origin[1];
    if(!drag.started && Math.abs(dx)+Math.abs(dy)<9) return;
    if(!drag.started) {checkpoint();drag.started=true;}
    drag.item.x=art.clamp(drag.offset[0]+dx,35,W-35);
    drag.item.y=art.clamp(drag.offset[1]+dy,35,H-35);
    paint();
  }
  function finishDrag(event) {
    if(!drag || drag.pointer!==event.pointerId) return;
    drag=null;
    updateInspector();
  }

  function getBook(id) {return store.books().find(function (book) {return book.id===id;});}
  function currentBook() {return getBook(state.reader.bookId);}
  function currentEntry() {
    const book=currentBook();
    return book && book.pages[state.reader.index];
  }
  function storageMessage() {
    if(state.loadingStore) return '正在读取手账…';
    if(state.storageError) return state.storageError;
    if(store.preview) return '浏览器试用 · 手账保留在本次打开期间。';
    if(!store.supported()) return '更新到小红书 9.49 或以上版本即可存入、翻阅手账。';
    return '';
  }
  function updateStorageText() {
    const help=storageMessage();
    $('save-support').hidden=!help;
    $('save-support').textContent=help;
    $('top-status').textContent=store.preview?'浏览器预览':'当前设备';
  }
  function renderLibrary() {
    const status=$('library-status');
    const message=storageMessage();
    status.hidden=!message;status.textContent=message;
    const root=$('book-list');
    root.textContent='';
    const books=store.books();
    if(!books.length) {
      const empty=node('div','empty-library');
      const mark=node('span','empty-icon');mark.innerHTML=icon('book');
      empty.appendChild(mark);empty.appendChild(node('h2','','还没有手账本'));
      empty.appendChild(node('p','','做好一页后，存到一本旅行手账里。'));
      empty.appendChild(button('回到制作页',function () {showView('editor');},'button primary','edit'));
      root.appendChild(empty);
    }
    books.forEach(function (book) {
      const card=button('',function () {openReader(book.id,0);},'book-card');
      const cover=node('div','book-cover');
      const first=book.pages[0];
      if(first) {const img=node('img');img.src=store.imageSource(first.thumb);img.alt='';cover.appendChild(img);}
      else cover.innerHTML=icon('book');
      card.appendChild(cover);
      card.appendChild(node('strong','',book.name));
      card.appendChild(node('small','',book.pages.length+' 页'+(first && first.city?' · '+first.city:'')));
      root.appendChild(card);
    });
  }
  function openReader(bookId,index) {
    state.reader={bookId:bookId,index:index};
    showView('reader');
  }
  function renderReader(direction) {
    const book=currentBook();
    if(!book) {showView('library');return;}
    state.reader.index=art.clamp(state.reader.index,0,Math.max(0,book.pages.length-1));
    const entry=book.pages[state.reader.index];
    $('reader-title').textContent=book.name;
    $('reader-count').textContent=entry?(state.reader.index+1)+' / '+book.pages.length+' 页':'0 页';
    $('reader-empty').hidden=!!entry;
    $('reader-image').hidden=!entry;
    readingFoot.textContent=entry?entry.title:'';
    $('reader-prev').disabled=state.reader.index<=0;
    $('reader-next').disabled=state.reader.index>=book.pages.length-1;
    ['edit-saved','reader-album','reader-publish','arrange'].forEach(function (action) {
      $('reader-view').querySelector('[data-action="'+action+'"]').disabled=!entry;
    });
    if(!entry) {$('reader-image').removeAttribute('src');return;}
    const image=$('reader-image');
    image.className='';
    image.src=store.imageSource(entry.preview);
    image.alt=entry.title;
    if(direction) {
      void image.offsetWidth;
      image.className=direction>0?'turn-next':'turn-prev';
    }
  }
  function flip(offset) {
    const book=currentBook();
    if(!book) return;
    const target=state.reader.index+offset;
    if(target<0 || target>=book.pages.length) return;
    state.reader.index=target;
    renderReader(offset);
  }
  async function editSaved() {
    const entry=currentEntry();
    if(!entry) return;
    if(state.dirty && !window.confirm('当前编辑页还没有保存，打开手账里这一页？')) return;
    const bookId=state.reader.bookId;
    const result=await store.loadPage(entry);
    setPage(result.page,result.assets,{bookId:bookId,pageId:entry.id},bookId);
    showView('editor');
  }

  function field(label,type,id) {
    const root=node('div');
    const lab=node('label','',label);lab.htmlFor=id;root.appendChild(lab);
    const input=node(type==='select'?'select':'input','field');
    if(type!=='select') {input.type=type;input.maxLength=24;}
    input.id=id;root.appendChild(input);
    return {root:root,input:input};
  }
  function validateStorage() {
    if(state.loadingStore || state.storageError || !store.supported()) {
      messageDialog('手账存储',storageMessage());
      return false;
    }
    return true;
  }
  function saveDialog() {
    if(!validateStorage()) return;
    const body=node('div');
    const draft=state.saved;
    const books=store.books();
    let pick,bookName;
    if(draft) {
      const book=getBook(draft.bookId);
      if(!book) throw new Error('原手账本已不可用。');
      body.appendChild(node('p','modal-note','更新《'+book.name+'》里已经保存的这一页，保留它的页序。'));
    } else {
      pick=field('存到哪一本','select','target-book');
      books.forEach(function (book) {
        const option=node('option','',book.name);option.value=book.id;pick.input.appendChild(option);
      });
      const newOption=node('option','','＋ 新建一本手账');newOption.value='';pick.input.appendChild(newOption);
      if(state.bookHint && getBook(state.bookHint)) pick.input.value=state.bookHint;
      body.appendChild(pick.root);
      bookName=field('手账本名称','text','new-book-name');
      bookName.root.style.marginTop='10px';
      bookName.input.value=state.page.city?state.page.city+'旅行手账':'';
      bookName.input.placeholder='例如：泉州周末';
      body.appendChild(bookName.root);
      function toggleNew() {bookName.root.hidden=!!pick.input.value;}
      pick.input.addEventListener('change',toggleNew);toggleNew();
    }
    const actions=node('div','modal-actions');
    const cancel=button('取消',closeModal);
    actions.appendChild(cancel);
    actions.appendChild(button(draft?'保存修改':'确认存入',async function () {
      const bookId=draft?draft.bookId:pick.input.value;
      const name=bookName && bookName.input.value.trim();
      if(!bookId && !name) {bookName.input.focus();throw new Error('给手账本起个名字吧。');}
      setModalBusy(true);cancel.disabled=true;
      try {
        const page=platform.copy(state.page);
        const assets=assetsFor(page);
        const preview=await art.exportPage(page,assets,1080,.86);
        const thumb=await art.exportPage(page,assets,216,.79);
        state.saved=await store.savePage({bookId:bookId,newName:name,pageId:draft && draft.pageId,page:page,assets:assets,preview:preview,thumb:thumb});
        state.bookHint=state.saved.bookId;state.dirty=false;
      } finally {setModalBusy(false);cancel.disabled=false;}
      closeModal();
      toast(draft?'这页已更新':'已存入我的手账');
    },'button primary'));
    body.appendChild(actions);openModal(draft?'保存这一页':'存入我的手账',body);
  }
  function createBookDialog() {
    if(!validateStorage()) return;
    const body=node('div');
    const name=field('手账本名称','text','create-book-name');
    name.input.placeholder='例如：泉州周末';body.appendChild(name.root);
    const actions=node('div','modal-actions');
    const cancel=button('取消',closeModal);
    actions.appendChild(cancel);
    actions.appendChild(button('创建手账本',async function () {
      if(!name.input.value.trim()) {name.input.focus();throw new Error('给手账本起个名字吧。');}
      setModalBusy(true);cancel.disabled=true;
      let bookId;
      try {bookId=await store.createBook(name.input.value.trim());}
      finally {setModalBusy(false);cancel.disabled=false;}
      closeModal();openReader(bookId,0);
    },'button primary'));
    body.appendChild(actions);openModal('新建手账本',body);
  }

  function arrangeDialog() {
    const book=currentBook();
    if(!book || !book.pages.length) return;
    const selected=currentEntry();
    const original=book.pages.slice();
    const pages=original.slice();
    const body=node('div');
    body.appendChild(node('p','modal-note','按住左侧拖动换页，或用箭头移动。保存后按新顺序翻阅。'));
    const list=node('ol','sort-list');body.appendChild(list);
    let sorting=null;
    function move(from,to) {
      if(to<0 || to>=pages.length || from===to) return;
      pages.splice(to,0,pages.splice(from,1)[0]);
      renderOrder();
    }
    function renderOrder() {
      list.textContent='';
      pages.forEach(function (entry,index) {
        const row=node('li','sort-item');
        row.dataset.index=String(index);
        const handle=button('',null,'drag-handle','grip');
        handle.setAttribute('aria-label','拖动第 '+(index+1)+' 页');
        row.appendChild(handle);
        const img=node('img');img.src=store.imageSource(entry.thumb);img.alt='';row.appendChild(img);
        row.appendChild(node('span','sort-label',(index+1)+'. '+entry.title));
        [['up','上移',-1],['down','下移',1]].forEach(function (option) {
          const arrow=button('',function () {move(index,index+option[2]);},'icon-button',option[0]);
          arrow.setAttribute('aria-label',option[1]+'第 '+(index+1)+' 页');
          arrow.disabled=index+option[2]<0 || index+option[2]>=pages.length;
          row.appendChild(arrow);
        });
        const remove=button('',function () {
          if(!window.confirm('从手账本移除「'+entry.title+'」？')) return;
          pages.splice(index,1);renderOrder();
        },'icon-button delete-button','trash');
        remove.setAttribute('aria-label','移除第 '+(index+1)+' 页');row.appendChild(remove);
        handle.addEventListener('pointerdown',function (event) {
          if(event.button!==0 || sorting) return;
          sorting={from:index,to:index,pointer:event.pointerId};
          handle.setPointerCapture(event.pointerId);
          row.classList.add('dragging');
          event.preventDefault();
        });
        handle.addEventListener('pointermove',function (event) {
          if(!sorting || sorting.pointer!==event.pointerId) return;
          const under=document.elementFromPoint(event.clientX,event.clientY);
          const next=under && under.closest('.sort-item');
          const target=next && list.contains(next)?Number(next.dataset.index):sorting.to;
          Array.from(list.children).forEach(function (element,position) {element.classList.toggle('drop-target',position===target && position!==index);});
          sorting.to=target;
          const box=$('modal').getBoundingClientRect();
          if(event.clientY>box.bottom-36) $('modal').scrollTop+=12;
          if(event.clientY<box.top+38) $('modal').scrollTop-=12;
        });
        function end(event) {
          if(!sorting || sorting.pointer!==event.pointerId) return;
          const object=sorting;sorting=null;
          row.classList.remove('dragging');
          Array.from(list.children).forEach(function (element) {element.classList.remove('drop-target');});
          if(event.type==='pointerup') move(object.from,object.to);
        }
        handle.addEventListener('pointerup',end);
        handle.addEventListener('pointercancel',end);
        handle.addEventListener('lostpointercapture',end);
        list.appendChild(row);
      });
      if(!pages.length) list.appendChild(node('li','modal-note','已移除所有页。保存后这会是一本空手账。'));
    }
    renderOrder();
    const controls=node('div','modal-actions');
    const cancel=button('取消',closeModal);controls.appendChild(cancel);
    controls.appendChild(button('保存页序',async function () {
      const order=pages.map(function (entry) {return entry.id;});
      setModalBusy(true);cancel.disabled=true;
      try {
        await store.updateBook(book.id,function (active) {
          const ids=active.pages.map(function (entry) {return entry.id;});
          if(ids.join(',')!==original.map(function (entry) {return entry.id;}).join(',')) throw new Error('页面已变化，请重新打开整理。');
          active.pages=order.map(function (id) {return active.pages.find(function (p) {return p.id===id;});});
        });
        if(selected) {
          const index=order.indexOf(selected.id);
          if(index>=0) state.reader.index=index;
        }
        if(state.saved && state.saved.bookId===book.id && order.indexOf(state.saved.pageId)<0) state.saved=null;
      } finally {setModalBusy(false);cancel.disabled=false;}
      closeModal();renderReader();toast('已保存页序');
    },'button primary'));
    body.appendChild(controls);openModal('整理页面',body);
  }

  function exportDialog(data,forNote) {
    const body=node('div');
    body.appendChild(node('p','modal-note',forNote
      ? '这张图会作为一页笔记的配图。请在小红书内打开后进入发布页。'
      : '长按或右键这张成品图即可保存。'));
    const img=node('img','export-image');
    img.src=data;img.alt='1080 × 1440 手账成品图';
    body.appendChild(img);
    const options=node('div','modal-actions');options.appendChild(button('完成',closeModal,'button primary'));body.appendChild(options);
    openModal(forNote?'发布预览':'保存成品图',body);
  }
  async function deliver(data,page,mode) {
    const sdk=store.sdk;
    if(store.preview) {exportDialog(data,mode==='publish');return;}
    if(!sdk || (mode==='album' && store.version()<9420)) {
      messageDialog('保存到手机相册','请更新小红书后保存成品图片。');
      return;
    }
    const method=mode==='album'?'saveImageToPhotosAlbum':'postNote';
    if(typeof sdk[method]!=='function') throw new Error('当前客户端暂时不支持这个操作。');
    let filePath=data;
    if(typeof sdk.writeTempFile==='function') {
      try {
        const file=await platform.call(sdk,'writeTempFile',{data:data});
        if(file.filePath) filePath=file.filePath;
      } catch (_) { /* Most ordinary images can be sent inline. */ }
    }
    if(mode==='album') {
      await platform.call(sdk,method,{filePath:filePath});
      toast('成品图已保存到手机相册');
      return;
    }
    const title=Array.from(page.title || (page.city?page.city+'旅行手账':'我的旅行手账')).slice(0,20).join('');
    const content=[page.city && page.date?page.city+' · '+page.date:page.city || page.date,page.caption].filter(Boolean).join('\n');
    const input={title:title,content:content,mediaInfo:{image_resources:[{url:filePath}]}};
    if(store.version()>=9430) input.pageType='photo_publish';
    await platform.call(sdk,method,input);
  }
  async function actionForPage(mode,fromReader) {
    if(fromReader) {
      const entry=currentEntry();
      if(!entry) return;
      const saved=await store.readPageInfo(entry);
      await deliver(await store.readImage(entry.preview),saved.page,mode);
      return;
    }
    const page=platform.copy(state.page);
    await deliver(await art.exportPage(page,assetsFor(page),1080,.9),page,mode);
  }

  function showMobileTools(panel) {
    setPanel(panel);
    document.querySelector('.sidebar').scrollIntoView();
    document.querySelector('[data-panel="'+panel+'"]').focus();
  }

  const actions={
    'mobile-layout':function () {showMobileTools('layout');},
    'mobile-paper':function () {showMobileTools('paper');},
    'mobile-decor':function () {showMobileTools('decor');},
    photos:function () {importPhotos();},
    background:function () {$('background-input').click();},
    'remove-background':function () {checkpoint();state.page.background=null;updatePaperChoices();paint();},
    undo:function () {turnHistory(true);},
    redo:function () {turnHistory(false);},
    new:function () {newPage('');},
    deselect:function () {state.selected='';updateInspector();paint();},
    'photo-crop':openPhotoCrop,
    front:function () {
      const item=editableItem();
      if(!item || item===state.page.items[state.page.items.length-1]) return;
      checkpoint();
      state.page.items.splice(state.page.items.indexOf(item),1);state.page.items.push(item);paint();
    },
    'remove-item':function () {
      const item=editableItem();
      if(!item) return;
      checkpoint();state.page.items.splice(state.page.items.indexOf(item),1);state.selected='';renderSlots();updateInspector();paint();
    },
    save:saveDialog,
    album:function () {return actionForPage('album',false);},
    publish:function () {return actionForPage('publish',false);},
    library:function () {showView('library');},
    'create-book':createBookDialog,
    arrange:arrangeDialog,
    prev:function () {flip(-1);},
    next:function () {flip(1);},
    'add-to-book':function () {newPage(state.reader.bookId);},
    'edit-saved':editSaved,
    'reader-album':function () {return actionForPage('album',true);},
    'reader-publish':function () {return actionForPage('publish',true);},
    'close-modal':closeModal
  };

  document.addEventListener('click',function (event) {
    const control=event.target.closest('[data-action],[data-view],[data-panel]');
    if(!control || control.disabled) return;
    if(control.dataset.action && actions[control.dataset.action]) {
      const name=control.dataset.action;
      if(name==='prev' || name==='next') actions[name]();
      else run(control,actions[name]);
    } else if(control.dataset.view) showView(control.dataset.view);
    else if(control.dataset.panel) setPanel(control.dataset.panel);
  });
  $('brand').addEventListener('click',function (event) {event.preventDefault();showView('editor');});
  $('modal-layer').addEventListener('click',function (event) {if(event.target===$('modal-layer')) closeModal();});
  document.addEventListener('keydown',function (event) {
    if(event.key==='Escape' && state.modalOpen) {event.preventDefault();closeModal();return;}
    if(state.modalOpen && event.key==='Tab') {
      const fields=Array.from($('modal').querySelectorAll('button,input,select,textarea')).filter(function (item) {return !item.disabled && item.offsetParent;});
      if(fields.length && event.shiftKey && (document.activeElement===fields[0] || document.activeElement===$('modal'))) {
        event.preventDefault();fields[fields.length-1].focus();
      } else if(fields.length && !event.shiftKey && document.activeElement===fields[fields.length-1]) {
        event.preventDefault();fields[0].focus();
      }
      return;
    }
    if(state.view==='reader' && !state.modalOpen) {
      if(event.key==='ArrowRight') {event.preventDefault();flip(1);}
      if(event.key==='ArrowLeft') {event.preventDefault();flip(-1);}
    }
  });
  ['title','city','date','caption'].forEach(function (key) {
    const el=$('page-'+key);
    el.addEventListener('input',function () {changeField(key,function () {state.page[key]=el.value;});});
    el.addEventListener('blur',function () {state.fieldKey='';});
  });
  const fieldBindings={
    'background-opacity':function (value) {state.page.background.opacity=Number(value)/100;},
    'item-scale':function (value) {editableItem().scale=Number(value)/100;},
    'item-rotation':function (value) {editableItem().rotation=Number(value);},
    'item-text':function (value) {editableItem().text=value;}
  };
  Object.keys(fieldBindings).forEach(function (key) {
    const field=$(key);
    field.addEventListener('input',function () {changeField(key,function () {fieldBindings[key](field.value);});});
    field.addEventListener('change',function () {state.fieldKey='';});
    field.addEventListener('blur',function () {state.fieldKey='';});
  });
  $('photo-input').addEventListener('change',function () {
    const el=this,files=Array.from(el.files);
    el.value='';run(null,function () {return addPhotos(files);});
  });
  $('background-input').addEventListener('change',function () {
    const el=this,file=el.files[0];
    el.value='';run(null,function () {return openBackground(file);});
  });
  canvas.addEventListener('pointerdown',hitPage);
  canvas.addEventListener('pointermove',movePage);
  ['pointercancel','pointerup','lostpointercapture'].forEach(function (key) {canvas.addEventListener(key,finishDrag);});
  const readerPage=$('reader-page');
  readerPage.addEventListener('pointerdown',function (event) {
    if(event.target!==$('reader-image') || event.button!==0) return;
    readerStart={pointer:event.pointerId,x:event.clientX,y:event.clientY};
    readerPage.setPointerCapture(event.pointerId);
  });
  readerPage.addEventListener('pointerup',function (event) {
    const start=readerStart;readerStart=null;
    if(!start || start.pointer!==event.pointerId) return;
    const dx=event.clientX-start.x,dy=event.clientY-start.y;
    if(Math.abs(dx)>47 && Math.abs(dx)>Math.abs(dy)*1.2) flip(dx<0?1:-1);
  });
  readerPage.addEventListener('pointercancel',function () {readerStart=null;});

  labelIcons(document);
  createOptions();
  setPage(sample());
  setPanel('layout');
  showView('editor');
  updateStorageText();
  store.initialized.catch(function () {
    state.storageError='手账存储暂时无法读取，重新打开小工具可以再试。';
  }).then(function () {
    state.loadingStore=false;updateStorageText();
    if(state.view==='library') renderLibrary();
  });
})();
