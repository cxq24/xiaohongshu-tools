(function () {
  'use strict';
  const art=window.JournalArt;
  const labels={instant:'拍立得',tear:'撕纸边',stamp:'邮票边',round:'圆形',ticket:'票据卡'};
  function coordinates(event,canvas) {
    const rect=canvas.getBoundingClientRect();
    return [
      (event.clientX-rect.left-canvas.clientLeft)*canvas.width/canvas.clientWidth,
      (event.clientY-rect.top-canvas.clientTop)*canvas.height/canvas.clientHeight
    ];
  }
  function bindDrag(canvas,begin,move,end) {
    let active=null;
    canvas.addEventListener('pointerdown',function (event) {
      if (active!==null || event.button!==0) return;
      event.preventDefault();
      active=event.pointerId;
      canvas.setPointerCapture(active);
      begin(coordinates(event,canvas));
    });
    canvas.addEventListener('pointermove',function (event) {
      if (event.pointerId===active) move(coordinates(event,canvas));
    });
    function finish(event) {
      if (event.pointerId!==active) return;
      active=null;
      if (end) end(event.type==='pointerup');
    }
    canvas.addEventListener('pointerup',finish);
    canvas.addEventListener('pointercancel',finish);
    canvas.addEventListener('lostpointercapture',finish);
  }
  function makeButton(label,fn,primary) {
    const b=document.createElement('button');
    b.type='button';
    b.className='button'+(primary?' primary':'');
    b.textContent=label;
    b.addEventListener('click',fn);
    return b;
  }
  function buttonRow(className) {
    const row=document.createElement('div');
    row.className=className;
    return row;
  }
  function normalize(file) {
    if (!file || (file.type && file.type.indexOf('image/')!==0)) return Promise.reject(new Error('请选择一张可以预览的图片。'));
    const source=URL.createObjectURL(file);
    return new Promise(function (resolve,reject) {
      const picture=new Image();
      picture.onload=function () {
        try {
          const scale=Math.min(1,1500/Math.max(picture.naturalWidth,picture.naturalHeight));
          const canvas=art.element(Math.max(1,Math.round(picture.naturalWidth*scale)),Math.max(1,Math.round(picture.naturalHeight*scale)));
          const ctx=canvas.getContext('2d');
          const alpha=file.type==='image/png' || file.type==='image/webp';
          if (!alpha) {ctx.fillStyle='#fffaf1';ctx.fillRect(0,0,canvas.width,canvas.height);}
          ctx.drawImage(picture,0,0,canvas.width,canvas.height);
          resolve(canvas.toDataURL(alpha?'image/png':'image/jpeg',.87));
        } catch (_) {reject(new Error('这张图片无法处理，可以换一张 JPG 或 PNG。'));}
        finally {URL.revokeObjectURL(source);}
      };
      picture.onerror=function () {
        URL.revokeObjectURL(source);
        reject(new Error('无法读取图片，可以先转换成 JPG 或 PNG。'));
      };
      picture.src=source;
    });
  }

  function markColor(source,mask,point,tolerance) {
    const w=source.width,h=source.height;
    const x=art.clamp(Math.floor(point[0]),0,w-1),y=art.clamp(Math.floor(point[1]),0,h-1);
    const pixels=source.getContext('2d').getImageData(0,0,w,h).data;
    const ctx=mask.getContext('2d');
    const output=ctx.getImageData(0,0,w,h);
    const seen=new Uint8Array(w*h), pending=new Int32Array(w*h);
    const start=y*w+x;
    const red=pixels[start*4],green=pixels[start*4+1],blue=pixels[start*4+2];
    const limit=tolerance*tolerance;
    let head=0,tail=1,changed=0;
    pending[0]=start;
    seen[start]=1;
    function queue(pixel) {
      if (seen[pixel]) return;
      seen[pixel]=1;
      const p=pixel*4;
      const dr=pixels[p]-red,dg=pixels[p+1]-green,db=pixels[p+2]-blue;
      if (dr*dr+dg*dg+db*db<=limit || pixels[p+3]===0) pending[tail++]=pixel;
    }
    while(head<tail) {
      const pixel=pending[head++];
      const p=pixel*4;
      if (output.data[p+3]!==255 && pixels[p+3]!==0) changed++;
      output.data[p+3]=255;
      const column=pixel%w;
      if (column>0) queue(pixel-1);
      if (column<w-1) queue(pixel+1);
      if (pixel>=w) queue(pixel-w);
      if (pixel<w*(h-1)) queue(pixel+w);
    }
    ctx.putImageData(output,0,0);
    return changed;
  }
  function composite(source,mask,into) {
    const ctx=into.getContext('2d');
    ctx.clearRect(0,0,into.width,into.height);
    ctx.drawImage(source,0,0);
    ctx.globalCompositeOperation='destination-out';
    ctx.drawImage(mask,0,0);
    ctx.globalCompositeOperation='source-over';
  }
  function stickerImage(canvas) {
    const w=canvas.width,h=canvas.height,pixels=canvas.getContext('2d').getImageData(0,0,w,h).data;
    let left=w,right=-1,top=h,bottom=-1;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
      if (pixels[(y*w+x)*4+3]<24) continue;
      left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
    }
    if (right<left || bottom<top) throw new Error('没有留下主体。可以点补回或重置。');
    const pad=11,sw=right-left+1,sh=bottom-top+1;
    const silhouette=art.element(sw,sh), sctx=silhouette.getContext('2d');
    sctx.drawImage(canvas,left,top,sw,sh,0,0,sw,sh);
    sctx.globalCompositeOperation='source-in';
    sctx.fillStyle='#fff9eb';sctx.fillRect(0,0,sw,sh);
    const output=art.element(sw+pad*2,sh+pad*2),ctx=output.getContext('2d');
    for (let i=0;i<14;i++) {
      const angle=i*Math.PI/7;
      ctx.drawImage(silhouette,pad+5*Math.cos(angle),pad+5*Math.sin(angle));
    }
    ctx.drawImage(canvas,left,top,sw,sh,pad,pad,sw,sh);
    return {data:output.toDataURL('image/png'),ratio:output.width/output.height};
  }

  function renderCrop(options) {
    const root=document.createElement('div');
    const message=document.createElement('p');
    message.className='modal-note';
    message.textContent=options.background
      ? '拖动或缩放，选好要铺满手账页的 3:4 区域。'
      : '先选样式，再拖动或缩放照片调整取景。';
    root.appendChild(message);

    const width=options.width || 1080,height=options.height || 1440;
    const previewScale=options.background?252/width:Math.min(290/width,335/height);
    const canvas=art.element(Math.round(width*previewScale),Math.round(height*previewScale));
    canvas.className='crop-stage'+(options.background?'':' crop-preview-frame');
    canvas.setAttribute('aria-label',options.background?'3:4 底图裁剪预览':'照片样式预览');
    root.appendChild(canvas);

    const bounds=options.sourceBox || [0,0,options.image.naturalWidth,options.image.naturalHeight];
    const crop=Object.assign({x:.5,y:.5,z:1},options.crop);
    let shape=labels[options.shape]?options.shape:'instant',start=null;
    const ctx=canvas.getContext('2d');

    function opening() {
      return options.background?{width:width,height:height}:art.photoOpening(shape,width,height);
    }
    function coverScale() {
      const frame=opening();
      return Math.max(frame.width/bounds[2],frame.height/bounds[3])*crop.z;
    }
    function render() {
      const frame=opening(), scale=coverScale();
      const minX=Math.min(.5,frame.width/scale/bounds[2]/2);
      const minY=Math.min(.5,frame.height/scale/bounds[3]/2);
      crop.x=art.clamp(crop.x,minX,1-minX);
      crop.y=art.clamp(crop.y,minY,1-minY);
      ctx.clearRect(0,0,canvas.width,canvas.height);
      if (options.background) {
        art.cover(ctx,options.image,0,0,canvas.width,canvas.height,crop,bounds);
        ctx.strokeStyle='rgba(255,255,255,.75)';
        for (let i=1;i<=2;i++) {
          ctx.beginPath();ctx.moveTo(canvas.width*i/3,0);ctx.lineTo(canvas.width*i/3,canvas.height);
          ctx.moveTo(0,canvas.height*i/3);ctx.lineTo(canvas.width,canvas.height*i/3);ctx.stroke();
        }
        return;
      }
      ctx.save();
      ctx.translate(canvas.width/2,canvas.height/2);
      ctx.scale(previewScale*.90,previewScale*.90);
      art.photoFrame(ctx,{w:width,h:height,shape:shape,crop:crop},options.image,bounds);
      ctx.restore();
    }

    if (!options.background) {
      const styles=buttonRow('crop-style-row');
      const buttons=Object.keys(labels).map(function (key) {
        const button=makeButton(labels[key],function () {shape=key;selectStyle();});
        button.dataset.shape=key;
        styles.appendChild(button);
        return button;
      });
      function selectStyle() {
        buttons.forEach(function (button) {
          const active=button.dataset.shape===shape;
          button.classList.toggle('active',active);
          button.setAttribute('aria-pressed',String(active));
        });
        render();
      }
      root.appendChild(styles);
      selectStyle();
    }

    const controls=buttonRow('crop-range');
    const label=document.createElement('label');
    label.htmlFor='crop-zoom';label.textContent='缩放';
    const zoom=document.createElement('input');
    zoom.type='range';zoom.min='100';zoom.max='300';zoom.id='crop-zoom';zoom.value=Math.round(crop.z*100);
    zoom.addEventListener('input',function () {crop.z=Number(zoom.value)/100;render();});
    controls.appendChild(label);controls.appendChild(zoom);root.appendChild(controls);
    bindDrag(canvas,function (point) {
      start={point:point,x:crop.x,y:crop.y};
    },function (point) {
      const scale=coverScale()*previewScale*(options.background?1:.90);
      crop.x=start.x-(point[0]-start.point[0])/scale/bounds[2];
      crop.y=start.y-(point[1]-start.point[1])/scale/bounds[3];
      render();
    },function () {start=null;});

    const actions=buttonRow('modal-actions');
    actions.appendChild(makeButton('取消',options.cancel));
    actions.appendChild(makeButton(options.background?'使用这张底图':'应用到页面',function () {
      options.apply({crop:Object.assign({},crop),shape:shape});
    },true));
    root.appendChild(actions);render();
    return root;
  }

  // Estimate background colors at the image boundary, then remove only
  // matching regions that are connected to that boundary.
  function estimateMask(source,mask) {
    const scale=Math.min(1,216/Math.max(source.width,source.height));
    const w=Math.max(1,Math.round(source.width*scale));
    const h=Math.max(1,Math.round(source.height*scale));
    const analysis=art.element(w,h);
    const ctx=analysis.getContext('2d');
    ctx.drawImage(source,0,0,w,h);
    const pixels=ctx.getImageData(0,0,w,h).data;
    const length=w*h;
    let transparent=0;
    for(let p=3;p<pixels.length;p+=4) if(pixels[p]<25) transparent++;
    if(transparent>length*.05) {
      mask.getContext('2d').clearRect(0,0,mask.width,mask.height);
      return 'transparent';
    }
    if(w<5 || h<5) return '';

    const border=[];
    for(let x=0;x<w;x++) border.push(x,(h-1)*w+x);
    for(let y=1;y<h-1;y++) border.push(y*w,y*w+w-1);
    const bins=new Map();
    border.forEach(function (index) {
      const p=index*4,r=pixels[p],g=pixels[p+1],b=pixels[p+2];
      const key=(r>>5)*64+(g>>5)*8+(b>>5);
      const group=bins.get(key) || [0,0,0,0];
      group[0]+=r;group[1]+=g;group[2]+=b;group[3]++;
      bins.set(key,group);
    });
    const colors=Array.from(bins.values()).sort(function (a,b) {return b[3]-a[3];}).slice(0,8).filter(function (group) {
      return group[3]>=border.length*.029;
    }).map(function (group) {
      const count=group[3];
      return [group[0]/count,group[1]/count,group[2]/count];
    });
    if (!colors.length) return '';

    const removed=new Uint8Array(length);
    const queue=new Int32Array(length);
    let tail=0,head=0;
    function visit(index) {
      if (removed[index]) return;
      const p=index*4;
      const matches=colors.some(function (color) {
        const r=pixels[p]-color[0],g=pixels[p+1]-color[1],b=pixels[p+2]-color[2];
        return r*r+g*g+b*b<=1710;
      });
      removed[index]=matches?2:1;
      if(matches) queue[tail++]=index;
    }
    border.forEach(visit);
    while(head<tail) {
      const index=queue[head++];
      const column=index%w;
      if(column>0) visit(index-1);
      if(column<w-1) visit(index+1);
      if(index>=w) visit(index-w);
      if(index<length-w) visit(index+w);
    }
    if(tail<length*.065 || tail>length*.94) return '';

    const outline=ctx.createImageData(w,h);
    for(let i=0;i<length;i++) if(removed[i]===2) outline.data[i*4+3]=255;
    ctx.putImageData(outline,0,0);
    const target=mask.getContext('2d');
    target.clearRect(0,0,mask.width,mask.height);
    target.drawImage(analysis,0,0,mask.width,mask.height);
    return 'masked';
  }

  function renderCutout(options) {
    const root=document.createElement('div');
    const status=document.createElement('p');
    status.className='cutout-status';
    status.setAttribute('role','status');
    const bounds=options.sourceBox || [0,0,options.image.naturalWidth,options.image.naturalHeight];
    const scale=Math.min(1,620/Math.max(bounds[2],bounds[3]));
    const w=Math.max(1,Math.round(bounds[2]*scale)),h=Math.max(1,Math.round(bounds[3]*scale));
    const source=art.element(w,h), mask=art.element(w,h), canvas=art.element(w,h);
    source.getContext('2d').drawImage(options.image,bounds[0],bounds[1],bounds[2],bounds[3],0,0,w,h);
    canvas.className='crop-stage sticker-stage crop-checker';
    canvas.setAttribute('aria-label','抠图预览');
    root.appendChild(status);root.appendChild(canvas);

    const instruction=document.createElement('p');
    instruction.className='modal-note cutout-instruction';
    const automatic=buttonRow('cutout-heading'), tools=buttonRow('cutout-tools'), actions=buttonRow('modal-actions');
    const maskContext=mask.getContext('2d');
    const history=[];
    let mode='outline',edited=false,polygon=null,last=null,busy=false;
    const guidance={
      outline:'用手指沿主体画一圈，松手后保留圈内。',
      color:'点一下背景，去掉相连的相近颜色。',
      erase:'在预览上涂掉多余的部分。',
      restore:'在预览上涂回想保留的部分。'
    };

    function paint() {composite(source,mask,canvas);}
    function checkpoint() {
      history.push({pixels:maskContext.getImageData(0,0,w,h),edited:edited});
      if(history.length>7) history.shift();
      undo.disabled=false;
    }
    function drawOutline() {
      const ctx=canvas.getContext('2d');
      ctx.clearRect(0,0,w,h);
      ctx.drawImage(source,0,0);
      if(polygon.length<2) return;
      ctx.strokeStyle='#fff7e7';ctx.lineWidth=6;ctx.lineJoin='round';
      ctx.beginPath();ctx.moveTo(polygon[0][0],polygon[0][1]);
      polygon.slice(1).forEach(function (p) {ctx.lineTo(p[0],p[1]);});
      ctx.stroke();
      ctx.strokeStyle='#a6513a';ctx.lineWidth=3;ctx.stroke();
    }
    function finishOutline() {
      if(polygon.length<4) {paint();return;}
      const xs=polygon.map(function (point) {return point[0];});
      const ys=polygon.map(function (point) {return point[1];});
      if((Math.max.apply(null,xs)-Math.min.apply(null,xs))*(Math.max.apply(null,ys)-Math.min.apply(null,ys))<w*h*.003) {
        paint();return;
      }
      checkpoint();
      maskContext.fillStyle='#000';maskContext.fillRect(0,0,w,h);
      maskContext.save();maskContext.globalCompositeOperation='destination-out';
      maskContext.beginPath();maskContext.moveTo(polygon[0][0],polygon[0][1]);
      polygon.slice(1).forEach(function (p) {maskContext.lineTo(p[0],p[1]);});
      maskContext.closePath();maskContext.fill();maskContext.restore();
      edited=true;status.textContent='已保留圈内主体。';paint();
    }
    function stroke(a,b) {
      maskContext.save();
      maskContext.globalCompositeOperation=mode==='restore'?'destination-out':'source-over';
      maskContext.strokeStyle='#000';maskContext.fillStyle='#000';
      const width=Math.max(7,Math.max(w,h)*.035);
      maskContext.lineWidth=width;maskContext.lineCap='round';
      if(a===b) {
        maskContext.beginPath();maskContext.arc(a[0],a[1],width/2,0,Math.PI*2);maskContext.fill();
      } else {
        maskContext.beginPath();maskContext.moveTo(a[0],a[1]);maskContext.lineTo(b[0],b[1]);maskContext.stroke();
      }
      maskContext.restore();edited=true;paint();
    }
    function runAutomatic(keepPrevious) {
      if(busy) return;
      busy=true;auto.disabled=true;apply.disabled=true;
      status.textContent='正在自动抠图…';
      requestAnimationFrame(function () {
        setTimeout(function () {
          if(!document.contains(root)) return;
          try {
            const prior=keepPrevious && {pixels:maskContext.getImageData(0,0,w,h),edited:edited};
            const result=estimateMask(source,mask);
            if(result) {
              if(prior) {history.push(prior);if(history.length>7) history.shift();undo.disabled=false;}
              edited=true;
              status.textContent=result==='transparent'?'已保留原图的透明区域。':'已生成抠图草稿，可以继续修边。';
            } else {
              status.textContent='自动抠图未找到清晰边缘。可以手动画圈保留主体。';
            }
          } catch (_) {status.textContent='可以用圈选主体，或擦除多余背景。';}
          finally {busy=false;auto.disabled=false;apply.disabled=false;paint();}
        },0);
      });
    }

    const auto=makeButton('自动抠图',function () {runAutomatic(true);});
    const undo=makeButton('撤销',function () {
      if(busy || !history.length) return;
      const saved=history.pop();
      maskContext.putImageData(saved.pixels,0,0);edited=saved.edited;
      undo.disabled=!history.length;status.textContent='已撤销上一步修整。';paint();
    });
    undo.disabled=true;
    automatic.appendChild(auto);automatic.appendChild(undo);
    const modeButtons=[['outline','圈选主体'],['color','点背景'],['erase','擦除'],['restore','补回']].map(function (entry) {
      const button=makeButton(entry[1],function () {mode=entry[0];syncTool();});
      button.dataset.tool=entry[0];tools.appendChild(button);
      return button;
    });
    function syncTool() {
      instruction.textContent=guidance[mode];
      modeButtons.forEach(function (button) {
        const active=button.dataset.tool===mode;
        button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
      });
    }
    bindDrag(canvas,function (p) {
      if(busy) return;
      if(mode==='outline') {polygon=[p];drawOutline();return;}
      checkpoint();
      if(mode==='color') {
        if(markColor(source,mask,p,52)) {edited=true;paint();}
      } else {last=p;stroke(p,p);}
    },function (p) {
      if(polygon) {polygon.push(p);drawOutline();}
      else if(last) {stroke(last,p);last=p;}
    },function (completed) {
      if(polygon && completed) finishOutline();
      else if(polygon) paint();
      polygon=null;last=null;
    });
    actions.appendChild(makeButton('取消',options.cancel));
    const apply=makeButton('贴到手账',function () {
      try {
        if(!edited) throw new Error('请先圈选主体，或擦掉一部分背景。');
        options.apply({sticker:stickerImage(canvas),mask:mask.toDataURL('image/png')});
      } catch (error) {options.onError(error.message);}
    },true);
    actions.appendChild(apply);
    root.appendChild(automatic);root.appendChild(tools);root.appendChild(instruction);root.appendChild(actions);
    syncTool();
    if(options.savedMask) {
      maskContext.drawImage(options.savedMask,0,0,w,h);
      status.textContent='继续修整这张贴纸。';edited=true;paint();
    } else {
      paint();
      runAutomatic(false);
    }
    return root;
  }

  window.JournalCrop={normalize:normalize,render:renderCrop,renderCutout:renderCutout};
})();
