(function () {
  'use strict';
  const W = 1080;
  const H = 1440;
  const catalog = window.JournalCatalog;
  const images = new Map();
  const papers = new Map();
  const serif = '"Songti SC","Noto Serif CJK SC",SimSun,serif';
  const sans = '"PingFang SC","Microsoft YaHei","Noto Sans CJK SC",sans-serif';
  const sampleSource = './assets/travel-samples.jpg';
  const sampleIds = ['sample-river','sample-food','sample-lane'];

  function clamp(number, low, high) { return Math.min(high, Math.max(low, number)); }
  function element(width, height) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    return canvas;
  }
  function imageRecord(source, onReady) {
    if (!source) return null;
    let record = images.get(source);
    if (!record) {
      const image = new Image();
      record = {image:image,ready:false};
      record.done = new Promise(function (resolve) {
        image.onload = function () { record.ready = true; resolve(image); };
        image.onerror = function () { resolve(null); };
        image.src = source;
      });
      images.set(source, record);
      if (images.size > 96) images.delete(images.keys().next().value);
      if (onReady) record.done.then(onReady);
    }
    return record;
  }
  function sourceFor(id, assets) {
    return sampleIds.indexOf(id) >= 0 ? sampleSource : assets[id];
  }
  function assetIDs(page) {
    const ids=[];
    page.items.forEach(function (item) {
      if(item.asset) ids.push(item.asset);
      if(item.originalAsset) ids.push(item.originalAsset);
      if(item.maskAsset) ids.push(item.maskAsset);
    });
    if(page.background) ids.push(page.background.asset);
    return Array.from(new Set(ids));
  }
  async function ready(page, assets) {
    const records = assetIDs(page).map(function (id) { return imageRecord(sourceFor(id, assets)); });
    const results = await Promise.all(records.map(function (r) { return r ? r.done : null; }));
    return results.every(function (result) { return !!result; });
  }
  function cover(ctx, image, dx, dy, dw, dh, crop, box) {
    const region = box || [0,0,image.naturalWidth || image.width,image.naturalHeight || image.height];
    const settings = crop || {x:.5,y:.5,z:1};
    const scale = Math.max(dw / region[2], dh / region[3]) * settings.z;
    const sw = dw / scale;
    const sh = dh / scale;
    const sx = clamp(region[0] + region[2] * settings.x - sw / 2, region[0], region[0] + region[2] - sw);
    const sy = clamp(region[1] + region[3] * settings.y - sh / 2, region[1], region[1] + region[3] - sh);
    ctx.drawImage(image,sx,sy,sw,sh,dx,dy,dw,dh);
  }
  function sourceBox(image, id) {
    const index = sampleIds.indexOf(id);
    if (index < 0) return null;
    const width = image.naturalWidth / 3;
    return [width * index + 1,1,width - 2,image.naturalHeight - 2];
  }
  function seedRandom(seed) {
    return function () {
      seed = (Math.imul(seed, 1664525) + 1013904223) | 0;
      return (seed >>> 0) / 4294967296;
    };
  }
  function paperImage(paper) {
    if (papers.has(paper.id)) return papers.get(paper.id);
    const canvas = element(W,H);
    const ctx = canvas.getContext('2d');
    const random = seedRandom(101);
    ctx.fillStyle = paper.base;
    ctx.fillRect(0,0,W,H);
    const glow = ctx.createRadialGradient(W*.32,H*.24,40,W*.48,H*.54,900);
    glow.addColorStop(0,'rgba(255,255,245,.38)');
    glow.addColorStop(1,'rgba(123,89,51,.12)');
    ctx.fillStyle = glow;
    ctx.fillRect(0,0,W,H);
    ctx.fillStyle = paper.line;
    ctx.strokeStyle = paper.line;
    ctx.globalAlpha = .14;
    for (let i=0;i<9800;i++) {
      const x = random()*W, y = random()*H;
      ctx.fillRect(x,y,random()*(paper.id==='fiber'?7:3)+.45,random()*1.3+.2);
    }
    ctx.globalAlpha = .32;
    ctx.lineWidth = 1.2;
    const kind = paper.pattern;
    if (kind==='grid' || kind==='ruled') {
      for (let y=42;y<H;y+=37) { ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke(); }
      if (kind==='grid') for (let x=34;x<W;x+=37) { ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke(); }
      if (kind==='ruled') ctx.fillRect(64,0,2,H);
    }
    if (kind==='dots') for(let y=30;y<H;y+=33) for(let x=30;x<W;x+=33) { ctx.beginPath();ctx.arc(x,y,1.65,0,Math.PI*2);ctx.fill(); }
    if (kind==='news') {
      for(let x=28;x<W-50;x+=177) {
        ctx.fillRect(x,0,1,H);
        for(let y=24;y<H;y+=14) {
          for(let z=0;z<5;z++) ctx.fillRect(x+6+z*30,y,10+random()*18,2+random()*2);
        }
      }
    }
    if (kind==='map') {
      for(let i=0;i<18;i++) {
        ctx.beginPath();
        ctx.moveTo(-40,60+i*77);
        ctx.bezierCurveTo(460+random()*245,120+i*31,400+random()*510,240+i*82,W+60,-230+i*103);
        ctx.stroke();
      }
      ctx.lineWidth=14;ctx.strokeStyle='#82989a';ctx.beginPath();ctx.moveTo(100,-10);ctx.bezierCurveTo(540,350,180,1040,W,H-160);ctx.stroke();
    }
    if (kind==='airmail') {
      for (let x=-40;x<W+40;x+=54) {
        ctx.fillStyle = x%108===-40 || x%108===68 ? '#a44d42' : '#546c8b';
        [0,H-16].forEach(function (y) { ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+32,y);ctx.lineTo(x+52,y+16);ctx.lineTo(x+20,y+16);ctx.fill(); });
      }
    }
    if (kind==='film') {
      ctx.fillStyle='#483e35';ctx.fillRect(0,0,43,H);ctx.fillRect(W-43,0,43,H);
      ctx.fillStyle='#fff7e4';
      for(let y=23;y<H;y+=53) {ctx.fillRect(10,y,22,27);ctx.fillRect(W-32,y,22,27);}
    }
    if (kind==='torn') {
      ctx.globalAlpha=.36;
      ['#cd9377','#8f9d76'].forEach(function (color,index) {
        ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(0,index?H:0);
        for(let x=0;x<=W;x+=30) ctx.lineTo(x,index?H-110+x*.18+random()*29:180-x*.17+random()*22);
        ctx.lineTo(W,index?H:0);ctx.closePath();ctx.fill();
      });
    }
    if (kind==='watercolor') {
      ctx.globalAlpha=.57;
      [[.12,.12,'#a2a98a'],[.90,.84,'#d49c9b'],[.92,.12,'#d9b797']].forEach(function (spot) {
        const g=ctx.createRadialGradient(spot[0]*W,spot[1]*H,20,spot[0]*W,spot[1]*H,460);
        g.addColorStop(0,spot[2]);g.addColorStop(1,'rgba(255,255,255,0)');
        ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
      });
    }
    ctx.globalAlpha=1;
    papers.set(paper.id,canvas);
    if (papers.size > 3) papers.delete(papers.keys().next().value);
    return canvas;
  }
  function path(ctx, shape, x, y, w, h) {
    ctx.beginPath();
    if (shape==='tear') {
      ctx.moveTo(x,y+5);
      const parts = 18;
      for(let n=0;n<=parts;n++) ctx.lineTo(x+w*n/parts,y+(n%3*2)+(n%2)*2);
      for(let n=1;n<=12;n++) ctx.lineTo(x+w-(n%3)*2,y+h*n/12);
      for(let n=parts-1;n>=0;n--) ctx.lineTo(x+w*n/parts,y+h-(n%4)*2);
      for(let n=12;n>=0;n--) ctx.lineTo(x+n%3*2,y+h*n/12);
      ctx.closePath();
    } else if (shape==='stamp') {
      const step = 14, notches = Math.max(2,Math.floor(w/step)), sides = Math.max(2,Math.floor(h/step));
      ctx.moveTo(x,y);
      for(let i=0;i<notches;i++) ctx.quadraticCurveTo(x+(i+.5)*w/notches,y+7,x+(i+1)*w/notches,y);
      for(let i=0;i<sides;i++) ctx.quadraticCurveTo(x+w-7,y+(i+.5)*h/sides,x+w,y+(i+1)*h/sides);
      for(let i=0;i<notches;i++) ctx.quadraticCurveTo(x+w-(i+.5)*w/notches,y+h-7,x+w-(i+1)*w/notches,y+h);
      for(let i=0;i<sides;i++) ctx.quadraticCurveTo(x+7,y+h-(i+.5)*h/sides,x,y+h-(i+1)*h/sides);
      ctx.closePath();
    } else if (shape==='ticket') {
      ctx.moveTo(x,y);ctx.lineTo(x+w,y);ctx.lineTo(x+w,y+h*.43);
      ctx.quadraticCurveTo(x+w-26,y+h*.5,x+w,y+h*.57);
      ctx.lineTo(x+w,y+h);ctx.lineTo(x,y+h);ctx.lineTo(x,y+h*.57);
      ctx.quadraticCurveTo(x+26,y+h*.5,x,y+h*.43);ctx.closePath();
    } else if (shape==='round') {
      ctx.ellipse(x+w/2,y+h/2,w/2,h/2,0,0,Math.PI*2);
    } else {
      ctx.rect(x,y,w,h);
    }
  }
  function textLines(ctx, text, x, y, width, lineHeight, max) {
    const chars = Array.from(text || '');
    let line='', lines=0;
    for(let i=0;i<chars.length;i++) {
      const char=chars[i];
      if (char==='\n' || (line && ctx.measureText(line+char).width>width)) {
        if (lines===max-1) { ctx.fillText(line+'…',x,y+lines*lineHeight);return; }
        ctx.fillText(line,x,y+lines*lineHeight);
        lines++;
        line=char==='\n'?'':char;
      } else { line+=char; }
    }
    if (line && lines<max) ctx.fillText(line,x,y+lines*lineHeight);
  }
  function photoOpening(shape,width,height) {
    if(shape==='round') width=height=Math.min(width,height);
    const pad=Math.min(shape==='instant'?17:11,width*.10,height*.10);
    const bottom=shape==='instant'?Math.min(48,height*.22):pad;
    return {x:-width/2+pad,y:-height/2+pad,width:width-pad*2,height:height-pad-bottom};
  }
  function photo(ctx, item, image, box) {
    const side=Math.min(item.w,item.h);
    const w=item.shape==='round'?side:item.w,h=item.shape==='round'?side:item.h,x=-w/2,y=-h/2;
    if (!image) return;
    if (item.shape==='cutout') {
      const scale=Math.min(w/image.naturalWidth,h/image.naturalHeight);
      const iw=image.naturalWidth*scale,ih=image.naturalHeight*scale;
      ctx.shadowColor='rgba(55,43,29,.25)';ctx.shadowBlur=12;ctx.shadowOffsetY=5;
      ctx.drawImage(image,-iw/2,-ih/2,iw,ih);
      return;
    }
    const opening=photoOpening(item.shape,w,h);
    ctx.save();
    ctx.shadowColor='rgba(56,43,27,.3)';ctx.shadowBlur=17;ctx.shadowOffsetY=8;
    path(ctx,item.shape,x,y,w,h);ctx.fillStyle='#fffaf0';ctx.fill();
    ctx.shadowColor='transparent';ctx.clip();
    path(ctx,item.shape==='round'?'round':'rect',opening.x,opening.y,opening.width,opening.height);
    ctx.clip();
    cover(ctx,image,opening.x,opening.y,opening.width,opening.height,item.crop,box || sourceBox(image,item.asset));
    ctx.restore();
  }

  function ornament(ctx, item, page) {
    const w=item.w,h=item.h;
    switch (item.type) {
      case 'ticket': {
        ctx.fillStyle='#d9a16f';ctx.shadowColor='rgba(118,81,60,0.3765)';ctx.shadowBlur=10;ctx.shadowOffsetY=5;
        path(ctx,'ticket',-w/2,-h/2,w,h);ctx.fill();ctx.shadowColor='transparent';
        ctx.strokeStyle='#9e5943';ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.strokeRect(-w/2+16,-h/2+15,w-32,h-30);ctx.setLineDash([]);
        ctx.fillStyle='#73412f';ctx.textAlign='center';ctx.font='700 26px '+serif;ctx.fillText('旅行留念',0,-2);
        ctx.font='17px '+sans;ctx.fillText((page.date || '旅行手账').replace(/-/g,' . '),0,29);break;
      }
      case 'tape': {
        ctx.fillStyle='rgba(187,155,96,.61)';path(ctx,'tear',-w/2,-h/2,w,h);ctx.fill();
        ctx.strokeStyle='rgba(255,245,199,.36)';ctx.lineWidth=2;
        for(let x=-w/2+6;x<w/2-6;x+=15) {ctx.beginPath();ctx.moveTo(x,-h/2+7);ctx.lineTo(Math.min(x+12,w/2-5),h/2-5);ctx.stroke();}
        break;
      }
      case 'stamp': {
        ctx.strokeStyle='#9e5141';ctx.globalAlpha=.85;ctx.lineWidth=3;
        const radius=Math.min(w,h)*.40;
        [radius,radius-9].forEach(function (r) {ctx.beginPath();ctx.arc(0,0,r,0,2*Math.PI);ctx.stroke();});
        ctx.fillStyle='#984b3a';ctx.textAlign='center';ctx.font='700 25px '+serif;ctx.fillText('一路留念',0,8);break;
      }
      case 'note': {
        ctx.fillStyle='#e1e5c3';ctx.shadowColor='rgba(74,96,52,0.2039)';ctx.shadowBlur=12;ctx.shadowOffsetY=6;
        path(ctx,'tear',-w/2,-h/2,w,h);ctx.fill();ctx.shadowColor='transparent';
        ctx.fillStyle='#49593a';ctx.font='700 24px '+serif;textLines(ctx,item.text || '今天的小事',-w/2+15,-h/2+37,w-30,32,2);break;
      }
      case 'route': {
        ctx.strokeStyle='#777f59';ctx.lineWidth=4;ctx.setLineDash([5,8]);ctx.beginPath();ctx.moveTo(-w/2,15);ctx.bezierCurveTo(-80,-55,22,75,w/2-12,-10);ctx.stroke();ctx.setLineDash([]);
        ctx.fillStyle='#a14f3b';ctx.beginPath();ctx.arc(w/2-12,-10,9,0,2*Math.PI);ctx.fill();break;
      }
      case 'spark': {
        ctx.fillStyle='#a86643';ctx.font='65px serif';ctx.textAlign='center';ctx.fillText('✦',0,18);break;
      }
    }
  }
  function draw(canvas, page, assets, options) {
    const ctx=canvas.getContext('2d');
    const paper=catalog.papers.find(function (p) {return p.id===page.paper;}) || catalog.papers[0];
    const selected=options && options.selected;
    const onReady=options && options.onReady;
    ctx.save();
    ctx.scale(canvas.width/W,canvas.height/H);
    ctx.drawImage(paperImage(paper),0,0);
    if (page.background) {
      const bg=imageRecord(sourceFor(page.background.asset,assets),onReady);
      if (bg && bg.ready) {
        ctx.globalAlpha=page.background.opacity;
        cover(ctx,bg.image,0,0,W,H,page.background.crop);
        ctx.globalAlpha=1;
        ctx.fillStyle='rgba(255,248,228,.12)';
        ctx.fillRect(0,0,W,H);
      }
    }
    ctx.fillStyle='#a4513a';
    ctx.font='700 24px '+sans;
    const date=[page.city,page.date && page.date.replace(/-/g,' . ')].filter(Boolean).join('   /   ');
    if (date) ctx.fillText(date,83,95,W-166);
    ctx.fillStyle=paper.ink;
    ctx.font='700 73px '+serif;
    textLines(ctx,page.title || '我的旅行手账',78,184,W-156,82,2);
    ctx.strokeStyle='#a4513a';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(85,219);ctx.quadraticCurveTo(176,207,270,214);ctx.stroke();
    if (page.layout==='timeline') {
      ctx.strokeStyle=paper.line;ctx.lineWidth=3;ctx.setLineDash([10,12]);ctx.beginPath();ctx.moveTo(W*.5,H*.24);ctx.lineTo(W*.5,H*.88);ctx.stroke();ctx.setLineDash([]);
    }
    if (page.caption) {
      ctx.save();
      ctx.translate(81,1255);
      ctx.rotate(-.023);
      ctx.fillStyle='rgba(255,250,234,.79)';
      path(ctx,'tear',-18,-22,W-142,127);ctx.fill();
      ctx.fillStyle=paper.ink;ctx.font='700 33px '+serif;
      textLines(ctx,page.caption,8,31,W-203,45,2);
      ctx.restore();
    }
    page.items.forEach(function (item) {
      ctx.save();ctx.translate(item.x,item.y);ctx.rotate(item.rotation*Math.PI/180);ctx.scale(item.scale,item.scale);
      ctx.save();
      if (item.kind==='photo') {
        const record=imageRecord(sourceFor(item.asset,assets),onReady);
        photo(ctx,item,record && record.ready ? record.image : null);
      } else ornament(ctx,item,page);
      ctx.restore();
      if (selected===item.id) {
        ctx.strokeStyle='#a4513a';ctx.lineWidth=3/item.scale;
        ctx.setLineDash([10,7]);
        ctx.strokeRect(-item.w/2-5,-item.h/2-5,item.w+10,item.h+10);
        ctx.setLineDash([]);ctx.fillStyle='#fff9ec';
        [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(function (corner) {
          ctx.beginPath();ctx.arc(corner[0]*(item.w/2+5),corner[1]*(item.h/2+5),7/item.scale,0,Math.PI*2);ctx.fill();ctx.stroke();
        });
      }
      ctx.restore();
    });
    ctx.restore();
  }
  function hit(item,x,y) {
    const dx=x-item.x,dy=y-item.y,angle=item.rotation*Math.PI/180;
    const rx=(dx*Math.cos(angle)+dy*Math.sin(angle))/item.scale;
    const ry=(-dx*Math.sin(angle)+dy*Math.cos(angle))/item.scale;
    return Math.abs(rx)<=item.w/2 && Math.abs(ry)<=item.h/2;
  }
  async function exportPage(page,assets,width,quality) {
    if (!await ready(page,assets)) throw new Error('有素材还未成功读取，请重新导入后再试。');
    const canvas=element(width,width*4/3);
    draw(canvas,page,assets);
    return canvas.toDataURL('image/jpeg',quality);
  }
  window.JournalArt={W:W,H:H,clamp:clamp,element:element,cover:cover,photoFrame:photo,photoOpening:photoOpening,sourceBox:sourceBox,imageRecord:imageRecord,sourceFor:sourceFor,assetIDs:assetIDs,draw:draw,hit:hit,exportPage:exportPage,sampleIds:sampleIds};
})();
