(function () {
  'use strict';

  const empty = function () { return {schema:1, version:0, books:[]}; };
  const copy = function (value) { return JSON.parse(JSON.stringify(value)); };
  const id = function () { return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,10); };

  function errorText(error) {
    if (error && error.message) return error.message;
    if (error && error.errMsg) return error.errMsg;
    return '操作没有完成，请稍后再试。';
  }
  function nativeCall(sdk, method, options) {
    return new Promise(function (resolve, reject) {
      if (!sdk || typeof sdk[method] !== 'function') {
        reject(new Error('当前环境不支持这一功能。'));
        return;
      }
      const input = Object.assign({}, options || {}, {success:resolve,fail:reject});
      try {
        const result = sdk[method](input);
        if (result && typeof result.then==='function') result.then(resolve,reject);
      } catch (error) { reject(error); }
    });
  }

  function asciiJson(value) {
    return JSON.stringify(value).replace(/[^\x00-\x7f]/g,function (character) {
      return '\\u' + ('0000'+character.charCodeAt(0).toString(16)).slice(-4);
    });
  }
  function parseImage(dataUrl) {
    const match = /^data:image\/(jpeg|png);base64,(.+)$/.exec(dataUrl || '');
    if (!match) throw new Error('这张图片无法保存。');
    return {extension:match[1]==='jpeg'?'jpg':'png', data:match[2]};
  }
  function getRefs(manifest) {
    const names = new Set();
    if (!manifest) return names;
    manifest.books.forEach(function (book) {
      book.pages.forEach(function (page) { page.files.forEach(function (file) { names.add(file); }); });
    });
    return names;
  }

  function createStore() {
    const xhs = window.xhs;
    const sdk = xhs && xhs.miniTool;
    const preview = !xhs;
    let supported = preview;
    let version = 0;
    let root = '';
    let limits = null;
    let manifest = empty();
    let previous = null;
    let activeSlot = -1;
    let busy = Promise.resolve();
    const inMemory = new Map();

    function path(name) { return root + '/' + name; }

    function operate(operation) {
      const result = busy.then(operation);
      busy = result.catch(function () {});
      return result;
    }

    async function read(name, encoding) {
      const {readChunkMaxBytes} = limits;
      const max = Number(readChunkMaxBytes);
      const length = encoding==='base64' ? max-max%3 : max;
      if (!(length>=3)) throw new Error('无法读取手账存储容量。');
      const chunks = [];
      let position=0;
      while (true) {
        const response = await nativeCall(sdk,'readFile',{filePath:path(name),encoding:encoding,position:position,length:length});
        chunks.push(response.data || '');
        if (response.eof) break;
        if (!(response.bytesRead>0) || (encoding==='base64' && response.bytesRead%3!==0)) throw new Error('手账文件读取不完整。');
        position+=response.bytesRead;
      }
      return chunks.join('');
    }

    async function write(name, data, encoding) {
      const max = Number(limits.writeChunkMaxBytes);
      const length=encoding==='base64'?max-max%4:max;
      if (!(length>=4)) throw new Error('当前客户端无法写入手账文件。');
      for (let offset=0;offset<data.length;offset+=length) {
        await nativeCall(sdk,offset?'appendFile':'writeFile',{
          filePath:path(name),encoding:encoding,data:data.slice(offset,offset+length)
        });
      }
    }
    function validManifest(value) {
      return value && value.schema===1 && Number.isInteger(value.version) && Array.isArray(value.books) &&
        value.books.every(function (book) {
          return typeof book.id==='string' && typeof book.name==='string' && Array.isArray(book.pages) &&
            book.pages.every(function (page) { return typeof page.id==='string' && Array.isArray(page.files); });
        });
    }
    async function initialize() {
      if (preview) return;
      if (!sdk) return;
      let env = xhs.launchOptions && xhs.launchOptions.miniToolEnv;
      if (!env || !env.buildVersion || !env.userDataPath) {
        try {
          const launch = await nativeCall(sdk,'getLaunchOptions');
          env = Object.assign({},env,launch && launch.miniToolEnv);
        } catch (_) { /* Missing capability stays disabled. */ }
      }
      version = Math.floor(Number(env && env.buildVersion || 0)/1000);
      if (version<9490 || !env.userDataPath || typeof sdk.getFileStorageInfo!=='function') return;
      root=env.userDataPath+'/travel-journal-v1';
      limits=await nativeCall(sdk,'getFileStorageInfo');
      try {
        await nativeCall(sdk,'mkdir',{dirPath:root,recursive:true});
      } catch (error) {
        const state=await nativeCall(sdk,'statFile',{filePath:root});
        if (!state.isDir) throw error;
      }
      const present = await nativeCall(sdk,'readDir',{dirPath:root});
      const names = present.files || [];
      const records = [];
      for (let slot=0;slot<2;slot++) {
        const name='books-'+slot+'.json';
        try {
          const value=JSON.parse(await read(name,'utf8'));
          if (validManifest(value)) records.push({slot:slot,value:value});
        } catch (_) { /* The other complete index is still available. */ }
      }
      records.sort(function (a,b) {return b.value.version-a.value.version;});
      if (records.length) {
        manifest=records[0].value;
        activeSlot=records[0].slot;
        previous=records[1] && records[1].value;
      } else {
        const namesKnown = names.some(function (entry) {
          const name=typeof entry==='string'?entry:(entry.name || entry.fileName || entry.filePath || '');
          return /books-[01]\.json$/.test(name);
        });
        if (namesKnown) throw new Error('找到了手账索引，但无法读取。');
      }
      supported=true;
    }
    async function removeFiles(files) {
      if (preview) {
        files.forEach(function (file) {inMemory.delete(file);});
        return;
      }
      for (const file of files) {
        try { await nativeCall(sdk,'unlink',{filePath:path(file)}); }
        catch (_) { /* Already absent or the container will reconcile it. */ }
      }
    }
    async function commit(next) {
      if (!supported) throw new Error('存入手账需要小红书 9.49 或以上版本。');
      next.version=manifest.version+1;
      const slot=activeSlot===0?1:0;
      if (!preview) await write('books-'+slot+'.json',asciiJson(next),'utf8');
      const keep=getRefs(next);
      getRefs(manifest).forEach(function (file) {keep.add(file);});
      const obsolete=Array.from(getRefs(previous)).filter(function (file) {return !keep.has(file);});
      previous=manifest;
      manifest=next;
      activeSlot=slot;
      await removeFiles(obsolete);
    }
    function getBook(state, bookId) { return state.books.find(function (book) {return book.id===bookId;}); }
    async function saveImage(name, dataUrl) {
      const binary=parseImage(dataUrl);
      if (preview) inMemory.set(name,dataUrl);
      else await write(name,binary.data,'base64');
    }
    function imageSource(name) {
      return preview?inMemory.get(name):path(name);
    }
    async function readImage(name) {
      if (preview) return inMemory.get(name);
      const subtype=name.slice(-4)==='.png'?'png':'jpeg';
      return 'data:image/'+subtype+';base64,'+await read(name,'base64');
    }
    function books() { return copy(manifest.books); }
    function createBook(name) {
      return operate(async function () {
        const next=copy(manifest);
        const book={id:id(),name:name,pages:[]};
        next.books.unshift(book);
        await commit(next);
        return book.id;
      });
    }
    function savePage(input) {
      return operate(async function () {
        if (!supported) throw new Error('当前环境无法存入手账。');
        const next=copy(manifest);
        let book=getBook(next,input.bookId);
        if (!book && input.newName) {
          book={id:id(),name:input.newName,pages:[]};
          next.books.unshift(book);
        }
        if (!book) throw new Error('请先选择一本手账。');
        const old=book.pages.findIndex(function (page) {return page.id===input.pageId;});
        if (input.pageId && old<0) throw new Error('原页面已移动或删除。');
        const prefix='p-'+id();
        const metadata=prefix+'.json';
        const previewName=prefix+'-preview.jpg';
        const thumb=prefix+'-thumb.jpg';
        const files=[metadata,previewName,thumb];
        const assets={};
        const entry={
          id:input.pageId || id(),title:input.page.title || '我的旅行手账',city:input.page.city,
          date:input.page.date,metadata:metadata,preview:previewName,thumb:thumb,files:files
        };
        let indexStarted=false;
        try {
          await saveImage(previewName,input.preview);
          await saveImage(thumb,input.thumb);
          for (const assetId of Object.keys(input.assets)) {
            const source=input.assets[assetId];
            const name=prefix+'-'+assetId+'.'+parseImage(source).extension;
            files.push(name);
            await saveImage(name,source);
            assets[assetId]=name;
          }
          const data={page:input.page,assets:assets};
          if (preview) inMemory.set(metadata,copy(data));
          else await write(metadata,asciiJson(data),'utf8');
          if (old>=0) book.pages[old]=entry;
          else book.pages.push(entry);
          indexStarted=true;
          await commit(next);
        } catch (error) {
          if (!indexStarted) await removeFiles(files);
          if (/quota|limit|space|容量|空间|超限/i.test(errorText(error))) throw new Error('手账本地空间不足。可以先把页面存到系统相册，再清理手账里的旧页。');
          throw error;
        }
        return {bookId:book.id,pageId:entry.id};
      });
    }
    async function readPageInfo(entry) {
      return preview?copy(inMemory.get(entry.metadata)):JSON.parse(await read(entry.metadata,'utf8'));
    }
    async function loadPage(entry) {
      const data=await readPageInfo(entry);
      const entries=await Promise.all(Object.keys(data.assets).map(async function (key) {
        return [key,await readImage(data.assets[key])];
      }));
      const assets={};
      entries.forEach(function (value) {assets[value[0]]=value[1];});
      return {page:data.page,assets:assets};
    }
    function updateBook(bookId, update) {
      return operate(async function () {
        const next=copy(manifest);
        const book=getBook(next,bookId);
        if (!book) throw new Error('找不到这本手账。');
        update(book);
        await commit(next);
      });
    }
    return {
      initialized:initialize(),books:books,createBook:createBook,savePage:savePage,loadPage:loadPage,
      readImage:readImage,readPageInfo:readPageInfo,imageSource:imageSource,updateBook:updateBook,
      supported:function () {return supported;},preview:preview,version:function () {return version;},sdk:sdk
    };
  }
  window.JournalStore={create:createStore,id:id,copy:copy,errorText:errorText,call:nativeCall};
})();
