(function () {
  'use strict';

  const byId = id => document.getElementById(id);
  const cover = window.NoteCover;
  const preview = byId('preview');
  const ctx = preview.getContext('2d');
  const title = byId('title');
  const subtitle = byId('subtitle');
  const fileInput = byId('files');
  const choose = byId('choose');
  const save = byId('save');
  const post = byId('post');
  const cropDialog = byId('crop-dialog');
  const cropCanvas = byId('crop-canvas');
  const zoom = byId('zoom');
  const exportDialog = byId('export-dialog');
  const targets = byId('photo-targets');
  const status = byId('status');
  const initialCrop = () => ({ x: .5, y: .5, zoom: 1 });
  const sampleTitle = '上海雨天也想去的\n三家咖啡馆';
  const sampleSubtitle = '静安 · 人均 45 元';
  const state = {
    template: 'cafe',
    photos: [],
    main: 0,
    title: sampleTitle,
    subtitle: sampleSubtitle,
    sample: true,
    color: 'paper',
    photoTheme: cover.paper
  };
  let design;
  let cropEdit;
  let drag;
  let pending = false;
  let composing = false;
  let statusTimer;
  let frameRequest;

  function notify(message) {
    clearTimeout(statusTimer);
    status.textContent = message;
    status.hidden = false;
    statusTimer = setTimeout(() => { status.hidden = true; }, 5000);
  }

  function updateActions() {
    const incomplete = !state.sample && (!state.title.trim() || Boolean(design.error));
    choose.disabled = pending;
    save.disabled = post.disabled = pending || composing || incomplete;
  }

  function updateTargets() {
    const selection = state.sample ? [] : design.photos;
    while (targets.children.length > selection.length) targets.lastElementChild.remove();
    selection.forEach(({ box, photo }, position) => {
      const button = targets.children[position] || document.createElement('button');
      if (!button.parentElement) {
        button.type = 'button';
        button.className = 'photo-target';
        targets.append(button);
      }
      button.setAttribute('aria-label', '调整第 ' + (state.photos.indexOf(photo) + 1) + ' 张照片的裁切');
      button.onclick = () => openCrop(photo, box);
      button.style.left = box.x / cover.width * 100 + '%';
      button.style.top = box.y / cover.height * 100 + '%';
      button.style.width = box.w / cover.width * 100 + '%';
      button.style.height = box.h / cover.height * 100 + '%';
    });
  }

  function render() {
    frameRequest = 0;
    design = cover.layout(ctx, state);
    cover.draw(preview, design);
    updateTargets();
    const hint = byId('layout-hint');
    const message = design.error || (!state.sample && !state.title.trim() ? '填写主标题后即可出图。' : '');
    if (hint.textContent !== message) hint.textContent = message;
    hint.hidden = !message;
    byId('photo-hint').hidden = state.template !== 'product' || state.photos.length < 2;
    updateActions();
  }

  function queueRender() {
    if (!frameRequest) frameRequest = requestAnimationFrame(render);
  }

  function updateButtons(selector, selected, key) {
    document.querySelectorAll(selector).forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset[key] === selected));
    });
  }

  function updateMainColor() {
    state.photoTheme = cover.themeFromPhoto(state.photos[state.main]?.image);
    byId('photo-color').style.backgroundColor = state.photoTheme.background;
  }

  function showPhotos() {
    const list = byId('photo-list');
    list.replaceChildren();
    byId('photo-section').hidden = state.sample;
    for (const [index, photo] of state.photos.entries()) {
      const button = document.createElement('button');
      const thumbnail = document.createElement('img');
      button.type = 'button';
      thumbnail.alt = '';
      thumbnail.src = photo.thumbnail;
      button.append(thumbnail, '照片 ' + (index + 1));
      button.setAttribute('aria-label', '将照片 ' + (index + 1) + ' 设为主图');
      button.setAttribute('aria-pressed', String(state.main === index));
      button.addEventListener('click', () => {
        if (state.main === index) return;
        state.main = index;
        Array.from(list.children).forEach((item, i) => item.setAttribute('aria-pressed', String(index === i)));
        updateMainColor();
        queueRender();
      });
      list.append(button);
    }
  }

  function loadImage(source) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.addEventListener('load', () => resolve(image), { once: true });
      image.addEventListener('error', reject, { once: true });
      image.src = source;
    });
  }

  function scaleImage(image, maxEdge) {
    const width = image.naturalWidth;
    const height = image.naturalHeight;
    const scale = Math.min(1, maxEdge / Math.max(width, height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  async function readPhoto(file) {
    const source = URL.createObjectURL(file);
    try {
      const original = await loadImage(source);
      return {
        image: scaleImage(original, 1800),
        thumbnail: scaleImage(original, 120).toDataURL('image/jpeg', .75),
        crop: initialCrop()
      };
    } finally {
      URL.revokeObjectURL(source);
    }
  }

  async function importPhotos(files) {
    if (!files.length || pending) return;
    pending = true;
    updateActions();
    byId('choose-label').textContent = '正在读取';
    const photos = [];
    const failed = [];
    try {
      for (const [index, file] of files.slice(0, 3).entries()) {
        try {
          photos.push(await readPhoto(file));
        } catch (_) {
          failed.push(index + 1);
        }
      }
      if (photos.length) {
        state.photos = photos;
        state.main = 0;
        if (state.sample) {
          if (title.value === sampleTitle) title.value = '';
          if (subtitle.value === sampleSubtitle) subtitle.value = '';
          state.title = title.value;
          state.subtitle = subtitle.value;
        }
        state.sample = false;
        byId('demo-tag').hidden = true;
        byId('preview-caption').textContent = '点任意照片调整裁切';
        showPhotos();
        updateMainColor();
        if (!matchMedia('(pointer: coarse)').matches && !state.title) title.focus();
      }

      const messages = [];
      if (files.length > 3) messages.push('最多使用前三张照片。');
      if (failed.length) {
        messages.push('第 ' + failed.join('、') + ' 张照片未能读取，可换成 JPEG 或 PNG。');
      }
      if (messages.length) notify(messages.join(''));
    } finally {
      pending = false;
      byId('choose-label').textContent = '选照片';
      render();
    }
  }

  function drawCrop() {
    const { photo, crop } = cropEdit;
    const ctx = cropCanvas.getContext('2d');
    const box = { x: 0, y: 0, w: cropCanvas.width, h: cropCanvas.height };
    ctx.fillStyle = design.theme.background;
    ctx.fillRect(0, 0, box.w, box.h);
    cover.drawPhoto(ctx, photo, crop, box);
    zoom.value = crop.zoom;
    byId('zoom-value').value = crop.zoom.toFixed(2) + '×';
  }

  function openCrop(photo, box) {
    cropEdit = { photo, crop: { ...photo.crop } };
    const scale = Math.min(390 / box.w, 420 / box.h);
    cropCanvas.width = Math.round(box.w * scale);
    cropCanvas.height = Math.round(box.h * scale);
    drawCrop();
    cropDialog.showModal();
  }

  function pan(source, dx, dy) {
    const { photo, crop } = cropEdit;
    const maxX = photo.image.width - source.w;
    const maxY = photo.image.height - source.h;
    const x = Math.min(maxX, Math.max(0, source.x - dx));
    const y = Math.min(maxY, Math.max(0, source.y - dy));
    crop.x = (x + source.w / 2) / photo.image.width;
    crop.y = (y + source.h / 2) / photo.image.height;
    drawCrop();
  }

  function cropSource() {
    return cover.cropGeometry(cropEdit.photo.image, cropEdit.crop, { w: cropCanvas.width, h: cropCanvas.height });
  }

  cropCanvas.addEventListener('pointerdown', event => {
    if (drag || event.button !== 0) return;
    drag = { x: event.clientX, y: event.clientY, pointer: event.pointerId, source: cropSource() };
    cropCanvas.setPointerCapture(event.pointerId);
  });
  cropCanvas.addEventListener('pointermove', event => {
    if (!drag || drag.pointer !== event.pointerId) return;
    const size = cropCanvas.getBoundingClientRect();
    pan(drag.source, (event.clientX - drag.x) / size.width * drag.source.w,
      (event.clientY - drag.y) / size.height * drag.source.h);
  });
  cropCanvas.addEventListener('lostpointercapture', () => { drag = null; });
  cropCanvas.addEventListener('keydown', event => {
    const direction = {
      ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1]
    }[event.key];
    if (!direction) return;
    event.preventDefault();
    const source = cropSource();
    pan(source, direction[0] * source.w * .04, direction[1] * source.h * .04);
  });
  zoom.addEventListener('input', () => {
    cropEdit.crop.zoom = Number(zoom.value);
    drawCrop();
  });
  byId('reset-crop').addEventListener('click', () => {
    cropEdit.crop = initialCrop();
    drawCrop();
  });
  byId('apply-crop').addEventListener('click', () => {
    cropEdit.photo.crop = cropEdit.crop;
    cropDialog.close();
    queueRender();
  });
  cropDialog.addEventListener('close', () => { cropEdit = drag = null; });

  function nativeCall(sdk, method, options, timeout = 20000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('timeout')), timeout);
      const success = value => { clearTimeout(timer); resolve(value); };
      const fail = error => { clearTimeout(timer); reject(error); };
      try {
        const result = sdk[method]({ ...options, success, fail });
        if (result && typeof result.then === 'function') result.then(success, fail);
      } catch (error) {
        fail(error);
      }
    });
  }

  function bindTopInset() {
    if (!window.xhs) return;
    const root = document.documentElement;
    root.dataset.container = 'xhs';
    const sdk = window.xhs.miniTool;
    if (typeof sdk?.getWindowInfo !== 'function') return;

    let revision = 0;
    let resizeTimer;
    async function update() {
      const request = ++revision;
      try {
        const info = await nativeCall(sdk, 'getWindowInfo', {}, 3000);
        if (request !== revision || !(info?.windowHeight > 0)) return;
        const topEdges = [info.safeArea?.top];
        if (Number.isFinite(info.statusBarHeight) && Number.isFinite(info.screenTop)) {
          topEdges.push(info.statusBarHeight - info.screenTop);
        } else {
          topEdges.push(info.statusBarHeight);
        }
        for (const key of ['back', 'me', 'share']) {
          const button = info.menuButtons?.[key];
          if (button?.height > 0) topEdges.push(button.bottom);
        }
        const available = topEdges.filter(edge => Number.isFinite(edge) && edge <= info.windowHeight);
        if (available.length) root.style.setProperty('--native-top', Math.max(0, ...available) + 'px');
      } catch (_) {
        // Keep the last known inset or the initial container spacing.
      }
    }
    function scheduleUpdate() {
      revision++;
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(update, 100);
    }
    update();
    window.addEventListener('resize', scheduleUpdate);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) scheduleUpdate(); });
  }

  async function exportCover(mode) {
    if (pending || composing) return;
    if (state.sample) {
      notify('先选自己的照片，再保存或发笔记。');
      return;
    }
    design = cover.layout(ctx, state);
    if (!state.title.trim() || design.error) return;
    const sdk = window.xhs?.miniTool;
    if (mode === 'post' && typeof sdk?.postNote !== 'function') {
      notify('请在小红书客户端内打开发笔记。');
      return;
    }

    pending = true;
    updateActions();
    const control = mode === 'post' ? post : save;
    const originalLabel = Array.from(control.childNodes);
    control.textContent = '正在出图…';
    control.setAttribute('aria-busy', 'true');
    try {
      const canvas = document.createElement('canvas');
      canvas.width = cover.width;
      canvas.height = cover.height;
      cover.draw(canvas, design);
      const data = canvas.toDataURL('image/jpeg', .9);
      if (!data.startsWith('data:image/jpeg;base64,')) throw new Error('Image encoding failed');
      if (mode === 'save' && !window.xhs) {
        byId('export-image').src = data;
        exportDialog.showModal();
        return;
      }
      if (mode === 'save' && typeof sdk?.saveImageToPhotosAlbum !== 'function') {
        notify('当前小红书版本无法保存相册。');
        return;
      }

      let path = data;
      if (data.length > 400000 && typeof sdk.writeTempFile === 'function') {
        try {
          const result = await nativeCall(sdk, 'writeTempFile', { data });
          path = result?.filePath || data;
        } catch (_) {
          // Some clients accept the smaller data URI directly.
        }
      }
      if (mode === 'post') {
        await nativeCall(sdk, 'postNote', { mediaInfo: { image_resources: [{ url: path }] } }, 90000);
      } else {
        await nativeCall(sdk, 'saveImageToPhotosAlbum', { filePath: path });
        notify('已保存到相册。');
      }
    } catch (error) {
      const message = String(error?.errMsg || error?.message || '');
      if (/cancel|取消/i.test(message)) return;
      notify(/permission|denied|auth|权限/i.test(message)
        ? '请在系统设置中允许小红书访问相册，再重试。'
        : mode === 'post' ? '暂时无法打开发布页，请重试。' : '保存封面失败，请重试。');
    } finally {
      pending = false;
      control.replaceChildren(...originalLabel);
      control.removeAttribute('aria-busy');
      updateActions();
    }
  }

  for (const button of document.querySelectorAll('[data-template]')) {
    button.addEventListener('click', () => {
      state.template = button.dataset.template;
      updateButtons('[data-template]', state.template, 'template');
      queueRender();
    });
  }
  for (const button of document.querySelectorAll('[data-color]')) {
    button.addEventListener('click', () => {
      state.color = button.dataset.color;
      updateButtons('[data-color]', state.color, 'color');
      queueRender();
    });
  }
  for (const [input, key] of [[title, 'title'], [subtitle, 'subtitle']]) {
    input.addEventListener('compositionstart', () => {
      composing = true;
      updateActions();
    });
    input.addEventListener('compositionend', () => {
      composing = false;
      state[key] = input.value;
      queueRender();
    });
    input.addEventListener('input', event => {
      if (composing || event.isComposing) return;
      state[key] = input.value;
      queueRender();
    });
    input.value = state[key];
  }

  byId('thumbnail').addEventListener('click', event => {
    const compact = byId('stage').classList.toggle('compact');
    event.currentTarget.setAttribute('aria-pressed', String(compact));
  });
  choose.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    const files = Array.from(fileInput.files);
    fileInput.value = '';
    importPhotos(files);
  });
  save.addEventListener('click', () => exportCover('save'));
  post.addEventListener('click', () => exportCover('post'));
  document.querySelector('[data-close="crop"]').addEventListener('click', () => cropDialog.close());
  document.querySelector('[data-close="export"]').addEventListener('click', () => exportDialog.close());
  exportDialog.addEventListener('close', () => byId('export-image').removeAttribute('src'));

  bindTopInset();
  render();
  loadImage('./assets/example.jpg').then(image => {
    if (!state.sample) return;
    state.photos = [{ image: scaleImage(image, 1800), crop: initialCrop() }];
    updateMainColor();
    queueRender();
  }).catch(() => { if (state.sample) notify('示例图片未加载，可以直接选照片。'); });
}());
