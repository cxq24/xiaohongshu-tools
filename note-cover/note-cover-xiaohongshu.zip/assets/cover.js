(function () {
  'use strict';

  const width = 1080;
  const height = 1440;
  const margin = 64;
  const gap = 24;
  const contentWidth = width - 2 * margin;
  const family = '"PingFang SC", "Noto Sans CJK SC", "Microsoft YaHei", sans-serif';
  const paper = { background: '#f7f0e2', foreground: '#242e24' };
  const ink = { background: '#212e27', foreground: '#fff8e8' };
  const punctuation = /^[、。，．！？；：）】》」』〉〕］｝”’.,!?:;%)]/u;
  const graphemes = typeof Intl.Segmenter === 'function'
    ? new Intl.Segmenter('zh', { granularity: 'grapheme' })
    : null;

  function segments(text) {
    return graphemes ? Array.from(graphemes.segment(text), part => part.segment) : Array.from(text);
  }

  function wrap(ctx, text, maxWidth, maxLines) {
    if (text.length > 240) return null;
    const fits = value => ctx.measureText(value).width <= maxWidth;
    const lines = [];
    for (const paragraph of text.split('\n')) {
      const words = paragraph.match(/[\p{Script=Latin}\p{Number}]+(?:[-'’][\p{Script=Latin}\p{Number}]+)*|\s+|[^\s\p{Script=Latin}\p{Number}]+/gu) || [];
      const tokens = words.flatMap(word => {
        if (/^\s/u.test(word)) return [' '];
        if (/^[\p{Script=Latin}\p{Number}]/u.test(word) && fits(word)) return [word];
        return segments(word);
      });
      let line = '';
      for (const token of tokens) {
        if (!line && token === ' ') continue;
        if (fits(line + token)) {
          line += token;
          continue;
        }
        if (punctuation.test(token)) {
          const before = segments(line.trimEnd());
          const last = before.pop();
          if (before.length && fits(last + token)) {
            lines.push(before.join('').trimEnd());
            line = last + token;
          } else {
            return null;
          }
        } else {
          if (!line || !fits(token)) return null;
          lines.push(line.trimEnd());
          line = token === ' ' ? '' : token;
        }
        if (lines.length >= maxLines) return null;
      }
      lines.push(line.trimEnd());
      if (lines.length > maxLines) return null;
    }
    return lines;
  }

  function typeset(ctx, title, subtitle, template) {
    const maxLines = template === 'guide' ? 3 : 2;
    const maxWidth = template === 'product' ? width - 168 : contentWidth;
    const heading = { lines: [], size: 96 };
    const sub = { lines: [], size: 38 };
    let error = '';
    if (title) {
      heading.lines = null;
      for (let size = 96; size >= 64; size -= 2) {
        ctx.font = '750 ' + size + 'px ' + family;
        const lines = wrap(ctx, title, maxWidth, maxLines);
        const height = lines && lines.length * size * 1.15 + (subtitle ? 60 : 0);
        if (lines && (template !== 'guide' || height <= 460 - margin - 28)) {
          heading.lines = lines;
          heading.size = size;
          break;
        }
      }
      if (!heading.lines) {
        error = template === 'guide' ? '主标题太长，请缩短文字。' : '主标题太长，请缩短文字或换「攻略标题」。';
      }
    }
    if (subtitle) {
      sub.lines = null;
      for (let size = 38; size >= 32; size -= 2) {
        ctx.font = '400 ' + size + 'px ' + family;
        const lines = wrap(ctx, subtitle, maxWidth, 1);
        if (lines) {
          sub.lines = lines;
          sub.size = size;
          break;
        }
      }
      if (!sub.lines && !error) error = '副标题太长，请缩短到一行。';
    }
    return { heading, sub, error };
  }

  function frame(x, y, w, h) {
    return { x, y, w, h };
  }

  function framesFor(template, count, top) {
    if (!count) return [];
    if (template === 'product') return [frame(84, 84, width - 168, 858)];
    if (template === 'guide') {
      const h = height - margin - top;
      if (count === 1) return [frame(margin, top, contentWidth, h)];
      const topH = Math.round((h - gap) * .64);
      const bottomWidth = (contentWidth - gap) / 2;
      return [
        frame(margin, top, contentWidth, topH),
        frame(margin, top + topH + gap, count === 2 ? contentWidth : bottomWidth, h - topH - gap),
        ...(count === 3 ? [frame(margin + bottomWidth + gap, top + topH + gap, bottomWidth, h - topH - gap)] : [])
      ];
    }

    const h = 944;
    if (count === 1) return [frame(margin, margin, contentWidth, h)];
    const mainWidth = Math.round((contentWidth - gap) * .66);
    const sideX = margin + mainWidth + gap;
    const sideW = contentWidth - mainWidth - gap;
    const sideH = (h - gap) / 2;
    return [
      frame(margin, margin, mainWidth, h),
      frame(sideX, margin, sideW, count === 2 ? h : sideH),
      ...(count === 3 ? [frame(sideX, margin + sideH + gap, sideW, sideH)] : [])
    ];
  }

  function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }

  function zoomRange(image, box) {
    const x = box.w / image.width;
    const y = box.h / image.height;
    const fill = Math.max(x, y);
    const fit = Math.min(x, y) / fill;
    return { fill, fit, min: Math.min(.65, fit) };
  }

  function cropGeometry(image, crop, box) {
    const range = zoomRange(image, box);
    const zoom = crop.fit ? range.fit : Math.max(range.min, crop.zoom);
    const scale = range.fill * zoom;
    const w = box.w / scale;
    const h = box.h / scale;
    return {
      x: w >= image.width ? (image.width - w) / 2 : clamp(crop.x * image.width - w / 2, 0, image.width - w),
      y: h >= image.height ? (image.height - h) / 2 : clamp(crop.y * image.height - h / 2, 0, image.height - h),
      w, h, scale, zoom
    };
  }

  function drawPhoto(ctx, photo, crop, box) {
    const source = cropGeometry(photo.image, crop, box);
    ctx.save();
    ctx.beginPath();
    ctx.rect(box.x, box.y, box.w, box.h);
    ctx.clip();
    ctx.drawImage(photo.image, box.x - source.x * source.scale, box.y - source.y * source.scale,
      photo.image.width * source.scale, photo.image.height * source.scale);
    ctx.restore();
  }

  function channels(hex) {
    return hex.match(/[\da-f]{2}/gi).map(pair => parseInt(pair, 16));
  }

  function luminance(rgb) {
    const linear = rgb.map(value => {
      const n = value / 255;
      return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4;
    });
    return .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2];
  }

  function themeFromPhoto(image) {
    if (!image) return paper;
    const sample = document.createElement('canvas');
    const scale = 96 / Math.max(image.width, image.height);
    sample.width = Math.max(1, Math.round(image.width * scale));
    sample.height = Math.max(1, Math.round(image.height * scale));
    const ctx = sample.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(image, 0, 0, sample.width, sample.height);
    const colors = window.PhotoPalette.colorsFrom(window.PhotoPalette.buildClusters(sample), 3);
    if (!colors.length) return paper;

    const selected = channels(colors[Math.floor(colors.length / 2)]);
    const neutral = channels('#efece0');
    const muted = selected.map((value, i) => Math.round(value * .46 + neutral[i] * .54));
    const background = '#' + muted.map(value => value.toString(16).padStart(2, '0')).join('');
    const l = luminance(muted);
    const foreground = [paper.foreground, '#ffffff'].find(color => {
      const t = luminance(channels(color));
      return (Math.max(l, t) + .05) / (Math.min(l, t) + .05) >= 4.5;
    });
    return foreground ? { background, foreground } : paper;
  }

  function layout(ctx, state) {
    const ordered = state.photos.length
      ? [state.photos[state.main], ...state.photos.filter((_, index) => index !== state.main)]
      : [];
    const copy = typeset(ctx, state.title.trim(), state.subtitle.trim(), state.template);
    const titleHeight = (copy.heading.lines || []).length * copy.heading.size * 1.15;
    const subHeight = copy.sub.lines && copy.sub.lines.length ? 16 + copy.sub.size * 1.15 : 0;
    const top = clamp(Math.ceil(margin + titleHeight + subHeight + 28), 330, 460);
    const boxes = framesFor(state.template, ordered.length, top);
    return {
      ...copy,
      x: state.template === 'product' ? 84 : margin,
      y: state.template === 'guide' ? margin : state.template === 'product' ? 1010 : 1063,
      theme: state.color === 'ink' ? ink : state.color === 'photo' ? state.photoTheme : paper,
      photos: boxes.map((box, index) => ({ box, photo: ordered[index] }))
    };
  }

  function draw(canvas, design) {
    const ctx = canvas.getContext('2d');
    ctx.save();
    ctx.scale(canvas.width / width, canvas.height / height);
    ctx.fillStyle = design.theme.background;
    ctx.fillRect(0, 0, width, height);
    for (const { box, photo } of design.photos) drawPhoto(ctx, photo, photo.crop, box);
    ctx.fillStyle = design.theme.foreground;
    ctx.textBaseline = 'top';
    let y = design.y;
    ctx.font = '750 ' + design.heading.size + 'px ' + family;
    for (const line of design.heading.lines || []) {
      ctx.fillText(line, design.x, y);
      y += design.heading.size * 1.15;
    }
    ctx.font = '400 ' + design.sub.size + 'px ' + family;
    for (const line of design.sub.lines || []) ctx.fillText(line, design.x, y + 16);
    ctx.restore();
  }

  window.NoteCover = { width, height, paper, layout, draw, drawPhoto, cropGeometry, zoomRange, themeFromPhoto };
}());
