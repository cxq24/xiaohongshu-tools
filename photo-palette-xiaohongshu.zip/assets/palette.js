(function () {
  "use strict";

  function toHex(rgb) {
    return "#" + rgb.map(function (channel) {
      return Math.round(channel).toString(16).padStart(2, "0");
    }).join("").toUpperCase();
  }

  function channelToLinear(channel) {
    const value = channel / 255;
    return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
  }

  // Cluster in OKLab so two similar-looking colors do not dominate the palette.
  function toLab(rgb) {
    const red = channelToLinear(rgb[0]);
    const green = channelToLinear(rgb[1]);
    const blue = channelToLinear(rgb[2]);
    const l = Math.cbrt(0.4122214708 * red + 0.5363325363 * green + 0.0514459929 * blue);
    const m = Math.cbrt(0.2119034982 * red + 0.6806995451 * green + 0.1073969566 * blue);
    const s = Math.cbrt(0.0883024619 * red + 0.2817188376 * green + 0.6299787005 * blue);
    return [
      0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
      1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
      0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    ];
  }

  function distance(a, b) {
    const lightness = (a[0] - b[0]) * 0.83;
    return lightness * lightness + Math.pow(a[1] - b[1], 2) + Math.pow(a[2] - b[2], 2);
  }

  function histogram(image) {
    const size = Math.min(1, 120 / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * size));
    canvas.height = Math.max(1, Math.round(image.height * size));
    const ctx = canvas.getContext("2d");
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const bytes = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const bins = new Map();

    for (let i = 0; i < bytes.length; i += 4) {
      const alpha = bytes[i + 3];
      if (alpha < 96) continue;
      const red = bytes[i];
      const green = bytes[i + 1];
      const blue = bytes[i + 2];
      const key = ((red >> 3) << 10) | ((green >> 3) << 5) | (blue >> 3);
      let bin = bins.get(key);
      if (!bin) {
        bin = { rgb: [0, 0, 0], weight: 0 };
        bins.set(key, bin);
      }
      const weight = alpha / 255;
      bin.rgb[0] += red * weight;
      bin.rgb[1] += green * weight;
      bin.rgb[2] += blue * weight;
      bin.weight += weight;
    }

    return Array.from(bins.values(), function (bin) {
      const rgb = bin.rgb.map(function (sum) { return sum / bin.weight; });
      return { rgb: rgb, lab: toLab(rgb), weight: bin.weight, nearest: Infinity };
    }).sort(function (a, b) { return b.weight - a.weight; });
  }

  function buildClusters(image) {
    const samples = histogram(image);
    if (!samples.length) return [];
    const centers = [samples[0].lab];

    while (centers.length < Math.min(18, samples.length)) {
      const latest = centers[centers.length - 1];
      let best = null;
      let bestScore = 0;
      samples.forEach(function (sample) {
        sample.nearest = Math.min(sample.nearest, distance(sample.lab, latest));
        const score = sample.nearest * Math.pow(sample.weight, 0.36);
        if (score > bestScore) {
          best = sample;
          bestScore = score;
        }
      });
      if (!best) break;
      centers.push(best.lab);
    }

    // The cluster RGB average gives a representative color for the sampled region.
    let clusters;
    for (let round = 0; round < 6; round += 1) {
      clusters = centers.map(function () { return { rgb: [0, 0, 0], weight: 0 }; });
      samples.forEach(function (sample) {
        let index = 0;
        let nearest = Infinity;
        centers.forEach(function (center, i) {
          const d = distance(sample.lab, center);
          if (d < nearest) {
            nearest = d;
            index = i;
          }
        });
        const cluster = clusters[index];
        for (let channel = 0; channel < 3; channel += 1) {
          cluster.rgb[channel] += sample.rgb[channel] * sample.weight;
        }
        cluster.weight += sample.weight;
      });
      clusters.forEach(function (cluster, i) {
        if (!cluster.weight) return;
        cluster.rgb = cluster.rgb.map(function (sum) { return sum / cluster.weight; });
        cluster.lab = toLab(cluster.rgb);
        centers[i] = cluster.lab;
      });
    }

    return clusters.filter(function (cluster) { return cluster.weight > 0; });
  }

  function colorsFrom(clusters, count) {
    const colors = [];
    const candidates = clusters.slice();
    while (colors.length < count && candidates.length) {
      let winner = -1;
      let bestScore = 0;
      candidates.forEach(function (cluster, i) {
        const distinctness = colors.reduce(function (nearest, other) {
          return Math.min(nearest, distance(cluster.lab, other.lab));
        }, 0.04);
        if (distinctness < 0.0005) return;
        const saturation = Math.hypot(cluster.lab[1], cluster.lab[2]);
        const score = Math.pow(cluster.weight, 0.48) * Math.sqrt(distinctness) *
          (1 + Math.min(saturation, 0.3) * 2.5);
        if (score > bestScore) {
          winner = i;
          bestScore = score;
        }
      });
      if (winner < 0) break;
      colors.push(candidates.splice(winner, 1)[0]);
    }

    return colors.sort(function (a, b) { return a.lab[0] - b.lab[0]; })
      .map(function (color) { return toHex(color.rgb); });
  }

  window.PhotoPalette = { buildClusters: buildClusters, colorsFrom: colorsFrom, toHex: toHex };
}());
