(function () {
  "use strict";

  function byId(id) { return document.getElementById(id); }

  const canvas = byId("card");
  const placeholder = byId("preview-placeholder");
  const stage = byId("preview-stage");
  const editor = byId("editor");
  const swatches = byId("swatches");
  const fileInput = byId("file-input");
  const choose = byId("choose-photo");
  const example = byId("load-example");
  const title = byId("card-title");
  const hexToggle = byId("show-hex");
  const reset = byId("reset-colors");
  const save = byId("save-image");
  const post = byId("post-note");
  const status = byId("status");
  const countButtons = Array.from(document.querySelectorAll("[data-count]"));
  const layoutButtons = Array.from(document.querySelectorAll("[data-layout]"));

  const modal = byId("modal");
  const close = byId("close-modal");
  const pickerPane = byId("picker-pane");
  const imagePane = byId("image-pane");
  const exportImage = byId("export-image");
  const pickSurface = byId("pick-surface");
  const pickCanvas = byId("pick-canvas");
  const pickPoint = byId("pick-point");
  const pickedHex = byId("picked-hex");
  const pickedChip = byId("picked-chip");
  const apply = byId("apply-color");

  const state = {
    image: null,
    count: 5,
    colors: [],
    clusters: [],
    title: "",
    layout: "frame",
    showHex: true
  };
  let photoRequest = 0;
  let loading = false;
  let exporting = false;
  let exportData = "";
  let statusTimer;
  let dragDepth = 0;
  let restoreFocus;
  let pickIndex = 0;
  let pickX = 0;
  let pickY = 0;

  function announce(message, hold) {
    window.clearTimeout(statusTimer);
    status.hidden = false;
    status.textContent = message;
    statusTimer = window.setTimeout(function () { status.hidden = true; }, hold || 3500);
  }

  function updateAvailability() {
    const unavailable = loading || !state.image;
    countButtons.concat(layoutButtons, title, hexToggle, reset).forEach(function (button) {
      button.disabled = unavailable;
    });
    save.disabled = unavailable || exporting;
    post.disabled = unavailable || exporting;
    editor.setAttribute("aria-busy", String(loading));
    stage.setAttribute("aria-busy", String(loading));
  }

  function renderCard() {
    if (!state.image) return;
    window.PaletteCard.render(canvas, state, 1);
    canvas.style.width = Math.min(480, Math.round(430 * canvas.width / canvas.height)) + "px";
    canvas.setAttribute("aria-label", (state.title || "照片色卡") + "，配色 " + state.colors.join("、"));
    byId("preview-dimensions").textContent = canvas.width + " × " + canvas.height + " px";
    exportData = "";
  }

  function paintSwatches() {
    swatches.textContent = "";
    const fragment = document.createDocumentFragment();
    state.colors.forEach(function (hex, index) {
      const cell = document.createElement("div");
      const color = document.createElement("button");
      const code = document.createElement("span");
      cell.className = "swatch";
      color.type = "button";
      color.className = "swatch-color";
      color.style.backgroundColor = hex;
      color.setAttribute("data-index", index);
      color.setAttribute("aria-label", "替换第 " + (index + 1) + " 个颜色 " + hex);
      color.addEventListener("click", function () {
        if (!loading) openPicker(index, color);
      });
      code.className = "swatch-code";
      code.textContent = hex;
      cell.appendChild(color);
      cell.appendChild(code);
      fragment.appendChild(cell);
    });
    swatches.appendChild(fragment);
    byId("flat-hint").hidden = state.colors.length >= state.count;
  }

  function resetPalette() {
    state.colors = window.PhotoPalette.colorsFrom(state.clusters, state.count);
    paintSwatches();
    renderCard();
  }

  function imageFrom(source) {
    return new Promise(function (resolve, reject) {
      const image = new Image();
      image.onload = function () { resolve(image); };
      image.onerror = reject;
      image.src = source;
    });
  }

  function scaledCanvas(image, maxEdge) {
    const width = image.naturalWidth || image.width;
    const height = image.naturalHeight || image.height;
    if (!width || !height) throw new Error("Empty image");
    const scale = Math.min(1, maxEdge / Math.max(width, height));
    const result = document.createElement("canvas");
    result.width = Math.max(1, Math.round(width * scale));
    result.height = Math.max(1, Math.round(height * scale));
    const ctx = result.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.drawImage(image, 0, 0, result.width, result.height);
    return result;
  }

  async function loadPhoto(source, isExample, release) {
    const request = ++photoRequest;
    loading = true;
    updateAvailability();
    if (!state.image) placeholder.textContent = "正在读取照片…";
    try {
      const decoded = await imageFrom(source);
      if (request !== photoRequest) return;
      const photo = scaledCanvas(decoded, 1500);
      const clusters = window.PhotoPalette.buildClusters(photo);
      if (!clusters.length) throw new Error("Transparent image");
      state.image = photo;
      state.clusters = clusters;
      state.title = isExample ? "海边日落" : "";
      title.value = state.title;
      resetPalette();
      byId("source-tag").textContent = isExample ? "示例照片" : "我的照片";
      byId("preview-meta").hidden = false;
      example.hidden = isExample;
      placeholder.hidden = true;
      canvas.hidden = false;
      if (!isExample) announce("已生成照片色卡");
    } catch (error) {
      if (request !== photoRequest) return;
      if (isExample) {
        const message = "示例照片无法读取，请选择一张自己的照片。";
        if (!state.image) placeholder.textContent = message;
        announce(message);
      } else {
        const message = error.message === "Transparent image"
          ? "这张图片没有可取色的内容。"
          : "无法读取这张图片，请换成 JPG、PNG 或 WebP 再试。";
        if (!state.image) placeholder.textContent = "选择照片后，这里会显示色卡。";
        announce(message, 5000);
      }
    } finally {
      if (release) URL.revokeObjectURL(source);
      if (request === photoRequest) {
        loading = false;
        updateAvailability();
      }
    }
  }

  function selectFile(file) {
    if (!file) return;
    const isImage = file.type
      ? file.type.toLowerCase().indexOf("image/") === 0
      : /\.(jpe?g|png|webp|gif|avif|heic|heif|bmp)$/i.test(file.name);
    if (!isImage) {
      announce("请选择一张照片。");
      return;
    }
    if (file.size > 30 * 1024 * 1024) {
      announce("这张照片超过 30 MB，请换一张较小的照片。");
      return;
    }
    loadPhoto(URL.createObjectURL(file), false, true);
  }

  function setPressed(buttons, chosen) {
    buttons.forEach(function (button) {
      button.setAttribute("aria-pressed", String(button === chosen));
    });
  }

  function showModal(heading, trigger, picker) {
    restoreFocus = trigger;
    byId("modal-title").textContent = heading;
    pickerPane.hidden = !picker;
    imagePane.hidden = picker;
    modal.hidden = false;
    document.body.classList.add("modal-open");
    (picker ? pickSurface : close).focus();
  }

  function closeModal() {
    if (modal.hidden) return;
    modal.hidden = true;
    document.body.classList.remove("modal-open");
    exportImage.removeAttribute("src");
    if (restoreFocus && document.contains(restoreFocus)) restoreFocus.focus();
  }

  function openPicker(index, trigger) {
    pickIndex = index;
    const photo = scaledCanvas(state.image, 900);
    pickCanvas.width = photo.width;
    pickCanvas.height = photo.height;
    pickCanvas.getContext("2d").drawImage(photo, 0, 0);
    pickX = Math.round(photo.width / 2);
    pickY = Math.round(photo.height / 2);
    pickPoint.hidden = true;
    pickedHex.value = state.colors[index];
    updateHex();
    showModal("从照片取色", trigger, true);
  }

  function validHex() {
    const value = pickedHex.value.trim();
    if (!/^#?[0-9a-f]{6}$/i.test(value)) return "";
    return "#" + value.replace(/^#/, "").toUpperCase();
  }

  function updateHex() {
    const hex = validHex();
    apply.disabled = !hex;
    pickedHex.setAttribute("aria-invalid", String(!hex));
    pickedChip.style.backgroundColor = hex || "transparent";
  }

  function pickAt(x, y) {
    pickX = Math.min(pickCanvas.width - 1, Math.max(0, Math.floor(x)));
    pickY = Math.min(pickCanvas.height - 1, Math.max(0, Math.floor(y)));
    const pixel = pickCanvas.getContext("2d").getImageData(pickX, pickY, 1, 1).data;
    if (pixel[3] < 96) {
      announce("这里是透明区域，试试点照片的其他位置。");
      return;
    }
    pickedHex.value = window.PhotoPalette.toHex([pixel[0], pixel[1], pixel[2]]);
    pickPoint.style.left = (pickX + 0.5) / pickCanvas.width * 100 + "%";
    pickPoint.style.top = (pickY + 0.5) / pickCanvas.height * 100 + "%";
    pickPoint.hidden = false;
    updateHex();
  }

  function applyColor() {
    const hex = validHex();
    if (!hex) return;
    state.colors[pickIndex] = hex;
    paintSwatches();
    renderCard();
    restoreFocus = swatches.querySelector('[data-index="' + pickIndex + '"]');
    closeModal();
    announce("已替换颜色");
  }

  function cardData() {
    if (exportData) return exportData;
    let data = canvas.toDataURL("image/png");
    if (data.length > 1250000) {
      const reduced = document.createElement("canvas");
      let scale = 0.82;
      while (data.length > 1250000 && scale > 0.34) {
        window.PaletteCard.render(reduced, state, scale);
        data = reduced.toDataURL("image/png");
        scale *= 0.8;
      }
    }
    if (data === "data:," || data.length > 1250000) throw new Error("Image encoding failed");
    exportData = data;
    return exportData;
  }

  function withTimeout(operation, milliseconds) {
    return new Promise(function (resolve, reject) {
      const timer = window.setTimeout(function () {
        reject(new Error("timeout"));
      }, milliseconds);
      Promise.resolve(operation).then(function (result) {
        window.clearTimeout(timer);
        resolve(result);
      }, function (error) {
        window.clearTimeout(timer);
        reject(error);
      });
    });
  }

  async function exportCard(mode) {
    if (loading || exporting || !state.image) return;
    const bridge = window.xhs && window.xhs.miniTool;
    const posting = mode === "post";
    const method = posting ? "postNote" : "saveImageToPhotosAlbum";
    const nativeAvailable = bridge && typeof bridge[method] === "function";
    if (posting && !nativeAvailable) {
      announce("请在小红书内打开小工具后发笔记。");
      return;
    }
    exporting = true;
    updateAvailability();
    byId("save-label").textContent = posting ? "保存色卡" : "准备图片…";
    try {
      const data = cardData();
      if (!nativeAvailable) {
        exportImage.src = data;
        showModal("保存色卡", save, false);
        return;
      }
      if (posting) {
        await withTimeout(bridge.postNote({
          title: (state.title || "我的照片色卡").slice(0, 20),
          content: "从照片里提取的一组颜色。\n#照片色卡[话题]#",
          tags: "照片色卡",
          pageType: "photo_publish",
          mediaInfo: { image_resources: [{ url: data }] }
        }), 90000);
      } else {
        await withTimeout(bridge.saveImageToPhotosAlbum({ filePath: data }), 25000);
        announce("已保存到相册");
      }
    } catch (error) {
      const message = String(error && (error.errMsg || error.message) || "");
      if (/cancel|取消/i.test(message)) return;
      if (/permission|denied|auth|权限/i.test(message)) {
        announce("请在系统设置中允许小红书访问照片，再试一次。", 5000);
      } else {
        announce(posting ? "暂时无法打开笔记发布页，请稍后重试。" : "保存失败，请重试。", 5000);
      }
    } finally {
      exporting = false;
      byId("save-label").textContent = "保存色卡";
      updateAvailability();
      if (!modal.hidden && imagePane.hidden === false) close.focus();
    }
  }

  function bindNativeButton(button, mode) {
    let lastPress = -Infinity;
    const pressEvent = window.PointerEvent ? "pointerdown" : "touchstart";
    button.addEventListener(pressEvent, function (event) {
      const api = window.xhs && window.xhs.miniTool;
      if (!api || (event.type === "pointerdown" && (event.pointerType === "mouse" || event.button !== 0))) return;
      lastPress = Date.now();
      exportCard(mode);
    });
    button.addEventListener("click", function () {
      if (Date.now() - lastPress >= 800) exportCard(mode);
    });
  }

  choose.addEventListener("click", function () { fileInput.click(); });
  fileInput.addEventListener("change", function () {
    const file = fileInput.files[0];
    fileInput.value = "";
    selectFile(file);
  });
  example.addEventListener("click", function () { loadPhoto("./assets/example.jpg", true); });
  stage.addEventListener("dragenter", function (event) {
    event.preventDefault();
    dragDepth += 1;
    stage.classList.add("is-dragging");
  });
  stage.addEventListener("dragover", function (event) { event.preventDefault(); });
  stage.addEventListener("dragleave", function () {
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) stage.classList.remove("is-dragging");
  });
  stage.addEventListener("drop", function (event) {
    event.preventDefault();
    dragDepth = 0;
    stage.classList.remove("is-dragging");
    selectFile(event.dataTransfer.files[0]);
  });

  countButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const count = Number(button.getAttribute("data-count"));
      if (count === state.count) return;
      state.count = count;
      setPressed(countButtons, button);
      resetPalette();
    });
  });
  layoutButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      state.layout = button.getAttribute("data-layout");
      setPressed(layoutButtons, button);
      renderCard();
    });
  });
  reset.addEventListener("click", function () {
    resetPalette();
    announce("已重新提取配色");
  });
  title.addEventListener("input", function () {
    state.title = title.value.trim();
    renderCard();
  });
  hexToggle.addEventListener("change", function () {
    state.showHex = hexToggle.checked;
    renderCard();
  });

  pickSurface.addEventListener("click", function (event) {
    if (!event.detail) return;
    const rect = pickCanvas.getBoundingClientRect();
    pickAt((event.clientX - rect.left) / rect.width * pickCanvas.width,
      (event.clientY - rect.top) / rect.height * pickCanvas.height);
  });
  pickSurface.addEventListener("keydown", function (event) {
    const offsets = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    const offset = offsets[event.key];
    if (offset) {
      event.preventDefault();
      pickAt(pickX + offset[0] * 9, pickY + offset[1] * 9);
    }
  });
  pickedHex.addEventListener("input", updateHex);
  pickedHex.addEventListener("keydown", function (event) {
    if (event.key === "Enter") applyColor();
  });
  apply.addEventListener("click", applyColor);
  close.addEventListener("click", closeModal);
  modal.addEventListener("click", function (event) {
    if (event.target === modal) closeModal();
  });
  modal.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closeModal();
    if (event.key !== "Tab") return;
    const items = pickerPane.hidden ? [close] : [close, pickSurface, pickedHex, apply].filter(function (item) {
      return !item.disabled;
    });
    const index = items.indexOf(document.activeElement);
    if (event.shiftKey && index === 0) {
      event.preventDefault();
      items[items.length - 1].focus();
    } else if (!event.shiftKey && index === items.length - 1) {
      event.preventDefault();
      items[0].focus();
    }
  });

  bindNativeButton(save, "save");
  bindNativeButton(post, "post");
  loadPhoto("./assets/example.jpg", true);
}());
