(function () {
  "use strict";

  const paper = "#fffaf3";
  const ink = "#382a2b";
  const sans = '"PingFang SC","Microsoft YaHei","Noto Sans CJK SC",sans-serif';
  const mono = '"SFMono-Regular",Consolas,monospace';

  function fill(ctx, color, x, y, width, height) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
  }

  function paintPhoto(ctx, image, x, y, width, height, cover) {
    const scale = cover
      ? Math.max(width / image.width, height / image.height)
      : Math.min(width / image.width, height / image.height);
    const drawWidth = image.width * scale;
    const drawHeight = image.height * scale;
    fill(ctx, "#eee5dc", x, y, width, height);
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, width, height);
    ctx.clip();
    ctx.drawImage(image, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
    ctx.restore();
  }

  function swatchRow(ctx, colors, x, y, width, height, gap) {
    const cell = (width - (colors.length - 1) * gap) / colors.length;
    colors.forEach(function (hex, i) {
      const start = Math.round(x + (cell + gap) * i);
      const end = Math.round(x + (cell + gap) * i + cell);
      fill(ctx, hex, start, y, end - start, height);
    });
    return cell;
  }

  function drawTitle(ctx, title, x, baseline, width) {
    ctx.font = "700 33px " + sans;
    ctx.fillStyle = ink;
    ctx.fillText(title, x, baseline, width);
  }

  function drawCodes(ctx, colors, x, baseline, cell, gap) {
    ctx.fillStyle = "#514447";
    ctx.font = "21px " + mono;
    ctx.textAlign = "center";
    colors.forEach(function (hex, i) {
      ctx.fillText(hex, x + i * (cell + gap) + cell / 2, baseline, cell - 6);
    });
    ctx.textAlign = "left";
  }

  function dimensions(state) {
    const title = state.title ? 51 : 0;
    const hex = state.showHex ? 32 : 0;
    if (state.layout === "colors") return { height: 325 + title + hex };
    if (state.layout === "edge") return { height: 670 + title + hex, photoHeight: 538 };
    const photoHeight = Math.max(335, Math.min(1060, Math.round(876 * state.image.height / state.image.width)));
    return { height: photoHeight + 157 + title + hex, photoHeight: photoHeight };
  }

  function render(canvas, state, scale) {
    const size = dimensions(state);
    const width = 960;
    canvas.width = Math.round(width * scale);
    canvas.height = Math.round(size.height * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.scale(canvas.width / width, canvas.height / size.height);
    ctx.imageSmoothingEnabled = true;
    fill(ctx, paper, 0, 0, width, size.height);

    if (state.layout === "frame") {
      paintPhoto(ctx, state.image, 42, 42, 876, size.photoHeight, false);
      let row = size.photoHeight + 69;
      if (state.title) {
        drawTitle(ctx, state.title, 42, row + 27, 876);
        row += 51;
      }
      const cell = swatchRow(ctx, state.colors, 42, row, 876, 53, 10);
      if (state.showHex) drawCodes(ctx, state.colors, 42, row + 83, cell, 10);
      return;
    }

    if (state.layout === "edge") {
      paintPhoto(ctx, state.image, 0, 0, width, size.photoHeight, true);
      const cell = swatchRow(ctx, state.colors, 0, size.photoHeight, width, 91, 0);
      if (state.showHex) drawCodes(ctx, state.colors, 0, size.photoHeight + 128, cell, 0);
      if (state.title) drawTitle(ctx, state.title, 42, size.height - 27, 876);
      return;
    }

    let row = 53;
    if (state.title) {
      drawTitle(ctx, state.title, 48, row + 26, 864);
      row += 51;
    }
    const cell = swatchRow(ctx, state.colors, 48, row, 864, 222, 12);
    if (state.showHex) drawCodes(ctx, state.colors, 48, row + 258, cell, 12);
  }

  window.PaletteCard = { render: render };
}());
